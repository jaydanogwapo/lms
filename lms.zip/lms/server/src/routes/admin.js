const express = require('express');
const bcrypt = require('bcryptjs');
const { z } = require('zod');
const { query } = require('../db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireAuth, requireStaff, requireAdmin } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth);

// ---------- Sections ----------
router.get('/sections', requireStaff, wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT s.id, s.name, s.description, s.created_at,
            COUNT(u.id) FILTER (WHERE u.role='student')::int AS student_count
     FROM sections s LEFT JOIN users u ON u.section_id = s.id
     GROUP BY s.id ORDER BY s.name`);
  res.json(rows);
}));

const sectionSchema = z.object({ name: z.string().trim().min(1).max(80), description: z.string().trim().max(300).optional().default('') });

router.post('/sections', requireAdmin, wrap(async (req, res) => {
  const d = sectionSchema.parse(req.body);
  const { rows } = await query('INSERT INTO sections (name, description) VALUES ($1,$2) RETURNING *', [d.name, d.description]);
  res.status(201).json(rows[0]);
}));

router.put('/sections/:id', requireAdmin, wrap(async (req, res) => {
  const d = sectionSchema.parse(req.body);
  const { rows } = await query('UPDATE sections SET name=$1, description=$2 WHERE id=$3 RETURNING *', [d.name, d.description, req.params.id]);
  if (!rows[0]) throw new HttpError(404, 'Section not found');
  res.json(rows[0]);
}));

router.delete('/sections/:id', requireAdmin, wrap(async (req, res) => {
  const c = await query(`SELECT COUNT(*)::int AS n FROM users WHERE section_id=$1`, [req.params.id]);
  if (c.rows[0].n > 0) throw new HttpError(409, 'Move or remove the students in this section before deleting it');
  const r = await query('DELETE FROM sections WHERE id=$1', [req.params.id]);
  if (!r.rowCount) throw new HttpError(404, 'Section not found');
  res.json({ ok: true });
}));

router.get('/sections/:id/students', requireStaff, wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT id, first_name, middle_name, last_name, email, email_verified, is_active
     FROM users WHERE role='student' AND section_id=$1 ORDER BY last_name, first_name`, [req.params.id]);
  res.json(rows);
}));

// ---------- Students ----------
router.get('/students', requireStaff, wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT u.id, u.first_name, u.middle_name, u.last_name, u.email, u.email_verified, u.is_active, u.section_id, s.name AS section_name
     FROM users u LEFT JOIN sections s ON s.id=u.section_id
     WHERE u.role='student' ORDER BY u.last_name, u.first_name`);
  res.json(rows);
}));

router.put('/students/:id/section', requireAdmin, wrap(async (req, res) => {
  const sectionId = z.number().int().positive().parse(Number(req.body.sectionId));
  const s = await query('SELECT id FROM sections WHERE id=$1', [sectionId]);
  if (!s.rows[0]) throw new HttpError(400, 'Section does not exist');
  const r = await query(`UPDATE users SET section_id=$1 WHERE id=$2 AND role='student'`, [sectionId, req.params.id]);
  if (!r.rowCount) throw new HttpError(404, 'Student not found');
  res.json({ ok: true });
}));

router.put('/students/:id/active', requireAdmin, wrap(async (req, res) => {
  const active = z.boolean().parse(req.body.active);
  const r = await query(`UPDATE users SET is_active=$1 WHERE id=$2 AND role='student'`, [active, req.params.id]);
  if (!r.rowCount) throw new HttpError(404, 'Student not found');
  res.json({ ok: true });
}));

// ---------- Teacher accounts (admin only) ----------
router.get('/teachers', requireAdmin, wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT id, role, first_name, last_name, email, is_active, created_at FROM users WHERE role IN ('teacher','admin') ORDER BY role, last_name`);
  res.json(rows);
}));

router.post('/teachers', requireAdmin, wrap(async (req, res) => {
  const d = z.object({
    firstName: z.string().trim().min(1).max(60), lastName: z.string().trim().min(1).max(60),
    email: z.string().trim().toLowerCase().email(), password: z.string().min(8).max(100),
    role: z.enum(['teacher', 'admin']).default('teacher'),
  }).parse(req.body);
  const { rows } = await query(
    `INSERT INTO users (role, first_name, last_name, email, password_hash, email_verified)
     VALUES ($1,$2,$3,$4,$5,true) RETURNING id, role, first_name, last_name, email`,
    [d.role, d.firstName, d.lastName, d.email, await bcrypt.hash(d.password, 12)]);
  res.status(201).json(rows[0]);
}));

router.put('/teachers/:id/active', requireAdmin, wrap(async (req, res) => {
  const active = z.boolean().parse(req.body.active);
  if (Number(req.params.id) === req.user.id) throw new HttpError(400, 'You cannot deactivate your own account');
  const r = await query(`UPDATE users SET is_active=$1 WHERE id=$2 AND role IN ('teacher','admin')`, [active, req.params.id]);
  if (!r.rowCount) throw new HttpError(404, 'Account not found');
  res.json({ ok: true });
}));

router.put('/teachers/:id/password', requireAdmin, wrap(async (req, res) => {
  const pw = z.string().min(8).max(100).parse(req.body.password);
  const r = await query(`UPDATE users SET password_hash=$1 WHERE id=$2 AND role IN ('teacher','admin')`, [await bcrypt.hash(pw, 12), req.params.id]);
  if (!r.rowCount) throw new HttpError(404, 'Account not found');
  res.json({ ok: true });
}));

// ---------- Courses ----------
router.get('/courses', requireStaff, wrap(async (_req, res) => {
  const { rows } = await query('SELECT * FROM courses ORDER BY title');
  res.json(rows);
}));
router.post('/courses', requireStaff, wrap(async (req, res) => {
  const d = z.object({ title: z.string().trim().min(1).max(120), description: z.string().trim().max(500).optional().default('') }).parse(req.body);
  const { rows } = await query('INSERT INTO courses (title, description, created_by) VALUES ($1,$2,$3) RETURNING *', [d.title, d.description, req.user.id]);
  res.status(201).json(rows[0]);
}));
router.delete('/courses/:id', requireAdmin, wrap(async (req, res) => {
  await query('DELETE FROM courses WHERE id=$1', [req.params.id]);
  res.json({ ok: true });
}));

module.exports = router;
