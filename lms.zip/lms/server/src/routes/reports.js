const express = require('express');
const ExcelJS = require('exceljs');
const PDFDocument = require('pdfkit');
const { query } = require('../db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireAuth, requireStaff } = require('../middleware/auth');

const router = express.Router();
router.use(requireAuth, requireStaff);

const n = (v) => Math.round(Number(v || 0) * 100) / 100;

async function overview() {
  const c = (await query(
    `SELECT
      (SELECT COUNT(*)::int FROM users WHERE role='student') AS students,
      (SELECT COUNT(*)::int FROM users WHERE role='teacher') AS teachers,
      (SELECT COUNT(*)::int FROM sections) AS sections,
      (SELECT COUNT(DISTINCT material_id)::int FROM lesson_sections) AS lessons,
      (SELECT COUNT(*)::int FROM activities) AS quizzes,
      (SELECT COUNT(*)::int FROM activities WHERE is_published) AS published_activities,
      (SELECT COUNT(DISTINCT student_id)::int FROM submissions) AS participating_students,
      (SELECT COALESCE(AVG(total_score / NULLIF(max_score,0)) * 100, 0) FROM submissions WHERE status='submitted' AND NOT needs_review) AS avg_percent`)).rows[0];
  // completion rate = submissions / (students in assigned sections x published activities)
  const exp = (await query(
    `SELECT COUNT(*)::int AS expected FROM activity_sections x
     JOIN activities a ON a.id=x.activity_id AND a.is_published
     JOIN users u ON u.section_id=x.section_id AND u.role='student' AND u.is_active`)).rows[0].expected;
  const done = (await query(`SELECT COUNT(*)::int AS n FROM submissions WHERE status='submitted'`)).rows[0].n;
  const bySection = (await query(
    `SELECT s.id, s.name,
            COUNT(DISTINCT u.id)::int AS students,
            COUNT(sb.id) FILTER (WHERE sb.status='submitted')::int AS submissions,
            COALESCE(AVG(sb.total_score / NULLIF(sb.max_score,0)) FILTER (WHERE sb.status='submitted' AND NOT sb.needs_review) * 100, 0) AS avg_percent,
            COUNT(DISTINCT sb.student_id)::int AS active_students
     FROM sections s LEFT JOIN users u ON u.section_id=s.id AND u.role='student'
     LEFT JOIN submissions sb ON sb.student_id=u.id
     GROUP BY s.id ORDER BY s.name`)).rows;
  const byActivity = (await query(
    `SELECT a.id, a.title, a.level,
            (SELECT COUNT(*)::int FROM activity_sections x JOIN users u ON u.section_id=x.section_id AND u.role='student' AND u.is_active WHERE x.activity_id=a.id) AS assigned,
            COUNT(sb.id) FILTER (WHERE sb.status='submitted')::int AS submitted,
            COALESCE(AVG(sb.total_score / NULLIF(sb.max_score,0)) FILTER (WHERE sb.status='submitted' AND NOT sb.needs_review) * 100, 0) AS avg_percent
     FROM activities a LEFT JOIN submissions sb ON sb.activity_id=a.id
     WHERE a.is_published GROUP BY a.id ORDER BY a.created_at DESC`)).rows;
  return {
    counts: { ...c, avg_percent: n(c.avg_percent) },
    participationRate: c.students ? n((c.participating_students / c.students) * 100) : 0,
    completionRate: exp ? n((done / exp) * 100) : 0,
    bySection: bySection.map((r) => ({ ...r, avg_percent: n(r.avg_percent), participation: r.students ? n((r.active_students / r.students) * 100) : 0 })),
    byActivity: byActivity.map((r) => ({ ...r, avg_percent: n(r.avg_percent), completion: r.assigned ? n((r.submitted / r.assigned) * 100) : 0 })),
  };
}

router.get('/overview', wrap(async (_req, res) => res.json(await overview())));

// ---- Exports ----
function sendWorkbook(res, wb, name) {
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', `attachment; filename="${name}.xlsx"`);
  return wb.xlsx.write(res).then(() => res.end());
}
function styleHeader(ws) {
  ws.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  ws.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1D4ED8' } };
  ws.columns.forEach((col) => { col.width = Math.max(14, col.width || 14); });
}

router.get('/export/overview.xlsx', wrap(async (_req, res) => {
  const o = await overview();
  const wb = new ExcelJS.Workbook();
  const s1 = wb.addWorksheet('Summary');
  s1.columns = [{ header: 'Metric', key: 'k', width: 34 }, { header: 'Value', key: 'v', width: 16 }];
  [['Registered students', o.counts.students], ['Teachers', o.counts.teachers], ['Sections', o.counts.sections], ['Published lessons', o.counts.lessons],
   ['Generated quizzes', o.counts.quizzes], ['Participation rate %', o.participationRate], ['Completion rate %', o.completionRate], ['Average score %', o.counts.avg_percent]]
    .forEach(([k, v]) => s1.addRow({ k, v })); styleHeader(s1);
  const s2 = wb.addWorksheet('By section');
  s2.columns = [{ header: 'Section', key: 'name', width: 24 }, { header: 'Students', key: 'students' }, { header: 'Submissions', key: 'submissions' }, { header: 'Participation %', key: 'participation' }, { header: 'Average %', key: 'avg_percent' }];
  o.bySection.forEach((r) => s2.addRow(r)); styleHeader(s2);
  const s3 = wb.addWorksheet('By activity');
  s3.columns = [{ header: 'Activity', key: 'title', width: 36 }, { header: 'Level', key: 'level' }, { header: 'Assigned students', key: 'assigned' }, { header: 'Submitted', key: 'submitted' }, { header: 'Completion %', key: 'completion' }, { header: 'Average %', key: 'avg_percent' }];
  o.byActivity.forEach((r) => s3.addRow(r)); styleHeader(s3);
  await sendWorkbook(res, wb, 'lms-overview-report');
}));

router.get('/export/overview.pdf', wrap(async (_req, res) => {
  const o = await overview();
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', 'attachment; filename="lms-overview-report.pdf"');
  const doc = new PDFDocument({ margin: 48 });
  doc.pipe(res);
  doc.fontSize(20).fillColor('#1d4ed8').text('LMS Performance Report');
  doc.fontSize(10).fillColor('#6b7280').text(`Generated ${new Date().toLocaleString('en-PH', { timeZone: 'Asia/Manila' })}`).moveDown();
  doc.fontSize(13).fillColor('#111827').text('Summary').moveDown(0.3);
  doc.fontSize(11);
  [['Registered students', o.counts.students], ['Teachers', o.counts.teachers], ['Sections', o.counts.sections], ['Published lessons', o.counts.lessons],
   ['Generated quizzes', o.counts.quizzes], ['Participation rate', `${o.participationRate}%`], ['Completion rate', `${o.completionRate}%`], ['Average score', `${o.counts.avg_percent}%`]]
    .forEach(([k, v]) => doc.text(`${k}: ${v}`));
  doc.moveDown().fontSize(13).text('Section performance').moveDown(0.3).fontSize(11);
  o.bySection.forEach((r) => doc.text(`${r.name} — ${r.students} students, ${r.submissions} submissions, participation ${r.participation}%, average ${r.avg_percent}%`));
  doc.moveDown().fontSize(13).text('Activities').moveDown(0.3).fontSize(11);
  o.byActivity.forEach((r) => doc.text(`${r.title} (${r.level}) — ${r.submitted}/${r.assigned} submitted (${r.completion}%), average ${r.avg_percent}%`));
  doc.end();
}));

async function activityResults(id) {
  const a = (await query('SELECT id, title, level FROM activities WHERE id=$1', [id])).rows[0];
  if (!a) throw new HttpError(404, 'Activity not found');
  const rows = (await query(
    `SELECT u.last_name, u.first_name, u.middle_name, u.email, s.name AS section, sb.status, sb.submitted_at, sb.total_score, sb.max_score, sb.needs_review, sb.feedback
     FROM users u
     JOIN activity_sections x ON x.section_id=u.section_id AND x.activity_id=$1
     LEFT JOIN sections s ON s.id=u.section_id
     LEFT JOIN submissions sb ON sb.student_id=u.id AND sb.activity_id=$1
     WHERE u.role='student' AND u.is_active ORDER BY s.name, u.last_name, u.first_name`, [id])).rows;
  return { a, rows };
}

router.get('/export/activity/:id.xlsx', wrap(async (req, res) => {
  const { a, rows } = await activityResults(req.params.id);
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('Results');
  ws.columns = [{ header: 'Section', key: 'section', width: 18 }, { header: 'Last name', key: 'last_name', width: 18 }, { header: 'First name', key: 'first_name', width: 18 },
    { header: 'Middle name', key: 'middle_name', width: 16 }, { header: 'Email', key: 'email', width: 30 }, { header: 'Status', key: 'status', width: 14 },
    { header: 'Score', key: 'score', width: 10 }, { header: 'Max', key: 'max', width: 10 }, { header: 'Percent', key: 'pct', width: 10 }, { header: 'Needs review', key: 'rev', width: 14 }, { header: 'Feedback', key: 'feedback', width: 40 }];
  rows.forEach((r) => ws.addRow({
    ...r, status: r.status || 'not_started', score: r.status === 'submitted' ? n(r.total_score) : '', max: r.status === 'submitted' ? n(r.max_score) : '',
    pct: r.status === 'submitted' && Number(r.max_score) ? n((r.total_score / r.max_score) * 100) : '', rev: r.needs_review ? 'Yes' : '', feedback: r.feedback || '' }));
  styleHeader(ws);
  await sendWorkbook(res, wb, `results-${a.id}`);
}));

router.get('/export/activity/:id.pdf', wrap(async (req, res) => {
  const { a, rows } = await activityResults(req.params.id);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `attachment; filename="results-${a.id}.pdf"`);
  const doc = new PDFDocument({ margin: 48 });
  doc.pipe(res);
  doc.fontSize(18).fillColor('#1d4ed8').text(`Results: ${a.title}`);
  doc.fontSize(10).fillColor('#6b7280').text(`Level: ${a.level}`).moveDown();
  doc.fontSize(11).fillColor('#111827');
  rows.forEach((r) => {
    const score = r.status === 'submitted' ? `${n(r.total_score)}/${n(r.max_score)}${r.needs_review ? ' (pending review)' : ''}` : (r.status === 'in_progress' ? 'In progress' : 'Not started');
    doc.text(`${r.section || '-'} | ${r.last_name}, ${r.first_name} | ${score}`);
  });
  doc.end();
}));

module.exports = router;
