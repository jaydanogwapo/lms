const express = require('express');
const { z } = require('zod');
const { query, pool } = require('../db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireAuth, requireStudent } = require('../middleware/auth');
const { autoGrade } = require('../services/grading');

const router = express.Router();
router.use(requireAuth, requireStudent);

// Loads an activity only if it is published to the student's own section.
async function getAccessibleActivity(user, id) {
  const { rows } = await query(
    `SELECT a.* FROM activities a JOIN activity_sections x ON x.activity_id=a.id AND x.section_id=$2
     WHERE a.id=$1 AND a.is_published`, [id, user.section_id]);
  if (!rows[0]) throw new HttpError(404, 'Activity not found');
  return rows[0];
}

router.get('/summary', wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT
       (SELECT COUNT(*)::int FROM lesson_sections WHERE section_id=$1) AS lessons,
       (SELECT COUNT(*)::int FROM activities a JOIN activity_sections x ON x.activity_id=a.id AND x.section_id=$1 WHERE a.is_published) AS activities,
       (SELECT COUNT(*)::int FROM submissions WHERE student_id=$2 AND status='submitted') AS submitted,
       (SELECT COUNT(*)::int FROM activities a JOIN activity_sections x ON x.activity_id=a.id AND x.section_id=$1
          LEFT JOIN submissions sb ON sb.activity_id=a.id AND sb.student_id=$2
          WHERE a.is_published AND COALESCE(sb.status,'not_started') <> 'submitted' AND a.deadline IS NOT NULL AND a.deadline > now() AND a.deadline < now() + interval '3 days') AS due_soon`,
    [req.user.section_id, req.user.id]);
  res.json(rows[0]);
}));

router.get('/activities', wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT a.id, a.title, a.instructions, a.level, a.deadline, a.published_at, a.release_scores, c.title AS course_title,
            COALESCE(sb.status, 'not_started') AS status, sb.total_score, sb.max_score, sb.needs_review,
            (SELECT COUNT(*)::int FROM questions q WHERE q.activity_id=a.id) AS question_count
     FROM activities a
     JOIN activity_sections x ON x.activity_id=a.id AND x.section_id=$1
     LEFT JOIN courses c ON c.id=a.course_id
     LEFT JOIN submissions sb ON sb.activity_id=a.id AND sb.student_id=$2
     WHERE a.is_published ORDER BY a.published_at DESC`, [req.user.section_id, req.user.id]);
  res.json(rows.map((r) => ({
    ...r,
    total_score: r.release_scores && r.status === 'submitted' ? Number(r.total_score) : null,
    max_score: r.release_scores && r.status === 'submitted' ? Number(r.max_score) : null,
    needs_review: undefined,
  })));
}));

// Questions WITHOUT answer keys, identical for every student in the section.
router.get('/activities/:id', wrap(async (req, res) => {
  const a = await getAccessibleActivity(req.user, req.params.id);
  const qs = (await query('SELECT id, qtype, prompt, choices, points FROM questions WHERE activity_id=$1 ORDER BY position', [a.id])).rows;
  const sb = (await query('SELECT * FROM submissions WHERE activity_id=$1 AND student_id=$2', [a.id, req.user.id])).rows[0];
  const responses = {};
  if (sb) (await query('SELECT question_id, response FROM answers WHERE submission_id=$1', [sb.id])).rows.forEach((r) => { responses[r.question_id] = r.response; });
  const out = {
    id: a.id, title: a.title, instructions: a.instructions, level: a.level, deadline: a.deadline,
    status: sb ? sb.status : 'not_started', pastDeadline: !!(a.deadline && new Date(a.deadline) < new Date()),
    questions: qs.map((q) => ({ id: q.id, qtype: q.qtype, prompt: q.prompt, choices: q.choices, points: Number(q.points) })),
    responses,
  };
  if (sb && sb.status === 'submitted' && a.release_scores) {
    const key = (await query(
      `SELECT q.id, CASE WHEN q.qtype='essay' THEN NULL ELSE q.answer_key END AS answer_key, ans.score, ans.feedback FROM questions q
       LEFT JOIN answers ans ON ans.question_id=q.id AND ans.submission_id=$1 WHERE q.activity_id=$2`, [sb.id, a.id])).rows;
    out.result = {
      totalScore: Number(sb.total_score), maxScore: Number(sb.max_score), feedback: sb.feedback, graded: !sb.needs_review,
      perQuestion: Object.fromEntries(key.map((k) => [k.id, { correctAnswer: k.answer_key, score: k.score == null ? null : Number(k.score), feedback: k.feedback }])),
    };
  }
  res.json(out);
}));

const answersSchema = z.record(z.string(), z.union([z.string().max(10000), z.array(z.string().max(500)).max(100), z.null()]));

async function saveAnswers(client, submissionId, activityId, answers) {
  const valid = new Set((await client.query('SELECT id FROM questions WHERE activity_id=$1', [activityId])).rows.map((r) => String(r.id)));
  for (const [qid, response] of Object.entries(answers)) {
    if (!valid.has(qid)) continue; // ignore ids that are not part of this activity
    await client.query(
      `INSERT INTO answers (submission_id, question_id, response) VALUES ($1,$2,$3)
       ON CONFLICT (submission_id, question_id) DO UPDATE SET response=$3`, [submissionId, Number(qid), JSON.stringify(response)]);
  }
}

async function openSubmission(client, a, studentId) {
  let sb = (await client.query('SELECT * FROM submissions WHERE activity_id=$1 AND student_id=$2 FOR UPDATE', [a.id, studentId])).rows[0];
  if (!sb) sb = (await client.query('INSERT INTO submissions (activity_id, student_id) VALUES ($1,$2) RETURNING *', [a.id, studentId])).rows[0];
  if (sb.status === 'submitted') throw new HttpError(409, 'You already submitted this activity');
  if (a.deadline && new Date(a.deadline) < new Date()) throw new HttpError(403, 'The deadline for this activity has passed');
  return sb;
}

router.put('/activities/:id/progress', wrap(async (req, res) => {
  const a = await getAccessibleActivity(req.user, req.params.id);
  const answers = answersSchema.parse(req.body.answers || {});
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const sb = await openSubmission(client, a, req.user.id);
    await saveAnswers(client, sb.id, a.id, answers);
    await client.query('UPDATE submissions SET updated_at=now() WHERE id=$1', [sb.id]);
    await client.query('COMMIT');
    res.json({ savedAt: new Date().toISOString() });
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}));

router.post('/activities/:id/submit', wrap(async (req, res) => {
  const a = await getAccessibleActivity(req.user, req.params.id);
  const answers = answersSchema.parse(req.body.answers || {});
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const sb = await openSubmission(client, a, req.user.id);
    await saveAnswers(client, sb.id, a.id, answers);
    const qs = (await client.query('SELECT * FROM questions WHERE activity_id=$1', [a.id])).rows;
    const stored = Object.fromEntries((await client.query('SELECT question_id, response FROM answers WHERE submission_id=$1', [sb.id])).rows.map((r) => [r.question_id, r.response]));
    let total = 0, max = 0, review = false;
    for (const q of qs) {
      const g = autoGrade(q, stored[q.id]);
      total += g.score; max += Number(q.points); review = review || g.needsReview;
      await client.query(
        `INSERT INTO answers (submission_id, question_id, score) VALUES ($1,$2,$3)
         ON CONFLICT (submission_id, question_id) DO UPDATE SET score=$3`, [sb.id, q.id, g.score]);
    }
    await client.query(
      `UPDATE submissions SET status='submitted', submitted_at=now(), auto_score=$1, total_score=$1, max_score=$2, needs_review=$3, updated_at=now() WHERE id=$4`,
      [total, max, review, sb.id]);
    await client.query('COMMIT');
    res.json({ submitted: true });
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}));

module.exports = router;
