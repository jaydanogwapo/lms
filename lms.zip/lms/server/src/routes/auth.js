const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { z } = require('zod');
const rateLimit = require('express-rate-limit');
const { query } = require('../db');
const { wrap, HttpError } = require('../middleware/errors');
const { signToken, setAuthCookie, clearAuthCookie, requireAuth } = require('../middleware/auth');
const { sendMail, layout, esc } = require('../services/mailer');

const router = express.Router();
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 60, standardHeaders: true, legacyHeaders: false });

const publicUser = (u) => ({
  id: u.id, role: u.role, firstName: u.first_name, middleName: u.middle_name, lastName: u.last_name,
  email: u.email, emailVerified: u.email_verified, sectionId: u.section_id, sectionName: u.section_name || null,
});

const nameRe = /^[\p{L}][\p{L}\s.'-]*$/u;
const registerSchema = z.object({
  firstName: z.string().trim().min(1).max(60).regex(nameRe, 'Invalid first name'),
  middleName: z.string().trim().max(60).regex(/^$|^[\p{L}][\p{L}\s.'-]*$/u, 'Invalid middle name').optional().default(''),
  lastName: z.string().trim().min(1).max(60).regex(nameRe, 'Invalid last name'),
  email: z.string().trim().toLowerCase().email().refine((e) => /@gmail\.com$/.test(e), 'A Gmail address (@gmail.com) is required'),
  password: z.string().min(8, 'Password must be at least 8 characters').max(100),
  sectionId: z.number().int().positive(),
});

async function issueVerification(user) {
  const raw = crypto.randomBytes(32).toString('hex');
  const hash = crypto.createHash('sha256').update(raw).digest('hex');
  await query('DELETE FROM email_verifications WHERE user_id=$1 AND used_at IS NULL', [user.id]);
  await query(`INSERT INTO email_verifications (user_id, token_hash, expires_at) VALUES ($1,$2, now() + interval '24 hours')`, [user.id, hash]);
  const url = `${process.env.APP_URL}/verify-email?token=${raw}`;
  return sendMail({
    userId: user.id, to: user.email, kind: 'verification', refType: 'user', refId: user.id,
    subject: 'Verify your Gmail address',
    html: layout('Verify your email', `<p>Hi ${esc(user.first_name)},</p><p>Please confirm that this Gmail account is yours to finish creating your student account. This link expires in 24 hours.</p>`, 'Verify my email', url),
  });
}

// Public: sections for the registration dropdown
router.get('/sections', wrap(async (_req, res) => {
  const { rows } = await query('SELECT id, name FROM sections ORDER BY name');
  res.json(rows);
}));

router.post('/register', limiter, wrap(async (req, res) => {
  const d = registerSchema.parse({ ...req.body, sectionId: Number(req.body.sectionId) });
  const sec = await query('SELECT id FROM sections WHERE id=$1', [d.sectionId]);
  if (!sec.rows[0]) throw new HttpError(400, 'Selected section does not exist');
  const hash = await bcrypt.hash(d.password, 12);
  const { rows } = await query(
    `INSERT INTO users (role, first_name, middle_name, last_name, email, password_hash, section_id)
     VALUES ('student',$1,$2,$3,$4,$5,$6) RETURNING *`,
    [d.firstName, d.middleName || null, d.lastName, d.email, hash, d.sectionId]);
  const sent = await issueVerification(rows[0]);
  res.status(201).json({
    message: sent
      ? 'Account created. Check your Gmail inbox for the verification link.'
      : 'Account created, but the verification email could not be sent. Use "Resend verification" after the administrator fixes email settings.',
    emailSent: sent,
  });
}));

router.post('/resend-verification', limiter, wrap(async (req, res) => {
  const email = z.string().trim().toLowerCase().email().parse(req.body.email);
  const { rows } = await query(`SELECT * FROM users WHERE email=$1 AND role='student' AND NOT email_verified`, [email]);
  if (rows[0]) await issueVerification(rows[0]);
  res.json({ message: 'If that account exists and is unverified, a new link has been sent.' });
}));

router.post('/verify-email', limiter, wrap(async (req, res) => {
  const token = z.string().min(20).parse(req.body.token);
  const hash = crypto.createHash('sha256').update(token).digest('hex');
  const { rows } = await query(
    `SELECT id, user_id FROM email_verifications WHERE token_hash=$1 AND used_at IS NULL AND expires_at > now()`, [hash]);
  if (!rows[0]) throw new HttpError(400, 'This verification link is invalid or has expired');
  await query('UPDATE email_verifications SET used_at=now() WHERE id=$1', [rows[0].id]);
  await query('UPDATE users SET email_verified=true WHERE id=$1', [rows[0].user_id]);
  res.json({ message: 'Email verified. You can now log in.' });
}));

async function login(req, res, roles) {
  const email = z.string().trim().toLowerCase().email().parse(req.body.email);
  const password = z.string().min(1).parse(req.body.password);
  const { rows } = await query(
    `SELECT u.*, s.name AS section_name FROM users u LEFT JOIN sections s ON s.id=u.section_id WHERE u.email=$1`, [email]);
  const u = rows[0];
  const ok = u && roles.includes(u.role) && (await bcrypt.compare(password, u.password_hash));
  if (!ok) throw new HttpError(401, 'Incorrect email or password');
  if (!u.is_active) throw new HttpError(403, 'This account has been deactivated');
  if (u.role === 'student' && !u.email_verified) throw new HttpError(403, 'Please verify your Gmail address first. Check your inbox for the link.');
  setAuthCookie(res, signToken(u));
  res.json({ user: publicUser(u) });
}

router.post('/staff-login', limiter, wrap((req, res) => login(req, res, ['admin', 'teacher'])));
router.post('/student-login', limiter, wrap((req, res) => login(req, res, ['student'])));

router.post('/logout', (_req, res) => { clearAuthCookie(res); res.json({ ok: true }); });

router.get('/me', requireAuth, wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT u.*, s.name AS section_name FROM users u LEFT JOIN sections s ON s.id=u.section_id WHERE u.id=$1`, [req.user.id]);
  res.json({ user: publicUser(rows[0]) });
}));

router.post('/change-password', requireAuth, wrap(async (req, res) => {
  const d = z.object({ currentPassword: z.string().min(1), newPassword: z.string().min(8).max(100) }).parse(req.body);
  const { rows } = await query('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
  if (!(await bcrypt.compare(d.currentPassword, rows[0].password_hash))) throw new HttpError(400, 'Current password is incorrect');
  await query('UPDATE users SET password_hash=$1 WHERE id=$2', [await bcrypt.hash(d.newPassword, 12), req.user.id]);
  res.json({ message: 'Password updated' });
}));

module.exports = router;
