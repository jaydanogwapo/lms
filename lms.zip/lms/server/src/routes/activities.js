const express = require('express');
const { z } = require('zod');
const { query, pool } = require('../db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireAuth, requireStaff } = require('../middleware/auth');
const { notifySections, esc } = require('../services/mailer');
const { TYPES } = require('../services/ai');

const router = express.Router();
router.use(requireAuth, requireStaff);

const LEVELS = ['beginner', 'intermediate', 'advanced'];

const questionSchema = z.object({
  id: z.number().int().positive().optional(),
  qtype: z.enum(TYPES),
  prompt: z.string().trim().min(1).max(2000),
  choices: z.array(z.string().trim().min(1).max(500)).min(2).max(8).nullable().optional(),
  answerKey: z.union([z.string(), z.array(z.string())]).nullable().optional(),
  points: z.coerce.number().min(0).max(100).default(1),
}).superRefine((q, ctx) => {
  if (q.qtype === 'multiple_choice') {
    if (!q.choices) return ctx.addIssue({ code: 'custom', message: 'Multiple choice needs choices' });
    if (typeof q.answerKey !== 'string' || !q.choices.includes(q.answerKey)) ctx.addIssue({ code: 'custom', message: 'Answer key must match one of the choices' });
  }
  if (q.qtype === 'true_false' && !['True', 'False'].includes(q.answerKey)) ctx.addIssue({ code: 'custom', message: 'True/False key must be True or False' });
  if (q.qtype === 'enumeration' && !(Array.isArray(q.answerKey) && q.answerKey.length)) ctx.addIssue({ code: 'custom', message: 'Enumeration needs a list of correct items' });
  if (['identification', 'short_answer'].includes(q.qtype) && !(typeof q.answerKey === 'string' && q.answerKey.trim())) ctx.addIssue({ code: 'custom', message: 'Answer key is required' });
});

const activitySchema = z.object({
  title: z.string().trim().min(1).max(160),
  instructions: z.string().trim().max(5000).optional().default(''),
  level: z.enum(LEVELS),
  deadline: z.string().datetime({ offset: true }).nullable().optional(),
  courseId: z.coerce.number().int().positive().nullable().optional(),
  materialId: z.coerce.number().int().positive().nullable().optional(),
  questions: z.array(questionSchema).min(1, 'Add at least one question'),
  sectionIds: z.array(z.number().int().positive()).optional().default([]),
});

const fmtDeadline = (d) => (d ? new Date(d).toLocaleString('en-PH', { timeZone: 'Asia/Manila', dateStyle: 'medium', timeStyle: 'short' }) : null);

function emailBody(a, intro) {
  return `<p>${intro}</p><p><b>${esc(a.title)}</b> &middot; ${esc(a.level)}</p>
    <p>${esc((a.instructions || '').slice(0, 300) || 'Open your dashboard to see the instructions.')}</p>
    ${a.deadline ? `<p><b>Deadline:</b> ${esc(fmtDeadline(a.deadline))}</p>` : ''}`;
}

async function saveQuestions(client, activityId, questions, allowDelete) {
  const existing = (await client.query('SELECT id FROM questions WHERE activity_id=$1', [activityId])).rows.map((r) => r.id);
  const keepIds = questions.filter((q) => q.id && existing.includes(q.id)).map((q) => q.id);
  const removed = existing.filter((id) => !keepIds.includes(id));
  if (removed.length) {
    if (!allowDelete) throw new HttpError(409, 'Questions cannot be removed after students have started this activity');
    await client.query('DELETE FROM questions WHERE id = ANY($1::int[])', [removed]);
  }
  let pos = 0;
  for (const q of questions) {
    pos += 1;
    const vals = [q.qtype, q.prompt, q.choices ? JSON.stringify(q.choices) : null, q.answerKey == null ? null : JSON.stringify(q.answerKey), q.points, pos];
    if (q.id && existing.includes(q.id)) {
      await client.query('UPDATE questions SET qtype=$1, prompt=$2, choices=$3, answer_key=$4, points=$5, position=$6 WHERE id=$7', [...vals, q.id]);
    } else {
      await client.query('INSERT INTO questions (qtype, prompt, choices, answer_key, points, position, activity_id) VALUES ($1,$2,$3,$4,$5,$6,$7)', [...vals, activityId]);
    }
  }
}

router.get('/', wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT a.id, a.title, a.level, a.deadline, a.is_published, a.published_at, a.release_scores, a.created_at,
            (SELECT COUNT(*)::int FROM questions q WHERE q.activity_id=a.id) AS question_count,
            (SELECT COALESCE(json_agg(json_build_object('id', s.id, 'name', s.name) ORDER BY s.name), '[]')
               FROM activity_sections x JOIN sections s ON s.id=x.section_id WHERE x.activity_id=a.id) AS sections,
            (SELECT COUNT(*)::int FROM submissions sb WHERE sb.activity_id=a.id AND sb.status='submitted') AS submitted_count,
            (SELECT COUNT(*)::int FROM submissions sb WHERE sb.activity_id=a.id AND sb.status='submitted' AND sb.needs_review) AS review_count
     FROM activities a ORDER BY a.created_at DESC`);
  res.json(rows);
}));

router.post('/', wrap(async (req, res) => {
  const d = activitySchema.parse(req.body);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const a = (await client.query(
      `INSERT INTO activities (course_id, material_id, title, instructions, level, deadline, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
      [d.courseId || null, d.materialId || null, d.title, d.instructions, d.level, d.deadline || null, req.user.id])).rows[0];
    await saveQuestions(client, a.id, d.questions, true);
    await client.query('COMMIT');
    res.status(201).json({ id: a.id });
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
}));

router.get('/:id', wrap(async (req, res) => {
  const a = (await query('SELECT * FROM activities WHERE id=$1', [req.params.id])).rows[0];
  if (!a) throw new HttpError(404, 'Activity not found');
  const qs = (await query('SELECT id, qtype, prompt, choices, answer_key, points FROM questions WHERE activity_id=$1 ORDER BY position', [a.id])).rows;
  const secs = (await query('SELECT section_id FROM activity_sections WHERE activity_id=$1', [a.id])).rows.map((r) => r.section_id);
  const subs = (await query('SELECT COUNT(*)::int AS n FROM submissions WHERE activity_id=$1', [a.id])).rows[0].n;
  res.json({
    id: a.id, title: a.title, instructions: a.instructions, level: a.level, deadline: a.deadline, courseId: a.course_id, materialId: a.material_id,
    isPublished: a.is_published, releaseScores: a.release_scores, sectionIds: secs, hasSubmissions: subs > 0,
    questions: qs.map((q) => ({ id: q.id, qtype: q.qtype, prompt: q.prompt, choices: q.choices, answerKey: q.answer_key, points: Number(q.points) })),
  });
}));

router.put('/:id', wrap(async (req, res) => {
  const d = activitySchema.parse(req.body);
  const a = (await query('SELECT * FROM activities WHERE id=$1', [req.params.id])).rows[0];
  if (!a) throw new HttpError(404, 'Activity not found');
  const hasSubs = (await query('SELECT COUNT(*)::int AS n FROM submissions WHERE activity_id=$1', [a.id])).rows[0].n > 0;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE activities SET title=$1, instructions=$2, level=$3, deadline=$4, course_id=$5, material_id=$6, updated_at=now() WHERE id=$7`,
      [d.title, d.instructions, d.level, d.deadline || null, d.courseId || null, d.materialId || null, a.id]);
    await saveQuestions(client, a.id, d.questions, !hasSubs);
    await client.query('COMMIT');
  } catch (e) { await client.query('ROLLBACK'); throw e; }
  finally { client.release(); }
  if (a.is_published) {
    const secs = (await query('SELECT section_id FROM activity_sections WHERE activity_id=$1', [a.id])).rows.map((r) => r.section_id);
    notifySections({
      sectionIds: secs, kind: 'activity_updated', refType: 'activity', refId: a.id,
      subject: `Updated: ${d.title}`, heading: 'An activity was updated',
      bodyHtml: emailBody({ ...d }, 'Your teacher updated this activity. Please review the latest version.'),
      ctaPath: '/student/activities',
    }).catch((e) => console.error('notify failed', e.message));
  }
  res.json({ ok: true });
}));

router.delete('/:id', wrap(async (req, res) => {
  const r = await query('DELETE FROM activities WHERE id=$1', [req.params.id]);
  if (!r.rowCount) throw new HttpError(404, 'Activity not found');
  res.json({ ok: true });
}));

// Publish (or add more sections to) an activity. Students in those sections get the identical stored questions.
router.post('/:id/publish', wrap(async (req, res) => {
  const d = z.object({ sectionIds: z.array(z.number().int().positive()).min(1, 'Select at least one section'), notify: z.boolean().optional().default(true) }).parse(req.body);
  const a = (await query('SELECT * FROM activities WHERE id=$1', [req.params.id])).rows[0];
  if (!a) throw new HttpError(404, 'Activity not found');
  const qn = (await query('SELECT COUNT(*)::int AS n FROM questions WHERE activity_id=$1', [a.id])).rows[0].n;
  if (!qn) throw new HttpError(400, 'Cannot publish an activity with no questions');
  const added = [];
  for (const sid of d.sectionIds) {
    const r = await query(
      `INSERT INTO activity_sections (activity_id, section_id) SELECT $1, id FROM sections WHERE id=$2 ON CONFLICT DO NOTHING RETURNING section_id`, [a.id, sid]);
    if (r.rows[0]) added.push(sid);
  }
  await query('UPDATE activities SET is_published=true, published_at=COALESCE(published_at, now()) WHERE id=$1', [a.id]);
  if (d.notify && added.length) {
    notifySections({
      sectionIds: added, kind: 'activity_published', refType: 'activity', refId: a.id,
      subject: `New activity: ${a.title}`, heading: 'A new activity was published',
      bodyHtml: emailBody(a, 'A new activity is waiting for you.'), ctaPath: '/student/activities',
    }).catch((e) => console.error('notify failed', e.message));
  }
  res.json({ published: added.length });
}));

router.post('/:id/unpublish', wrap(async (req, res) => {
  const sid = req.body.sectionId ? z.number().int().positive().parse(req.body.sectionId) : null;
  if (sid) await query('DELETE FROM activity_sections WHERE activity_id=$1 AND section_id=$2', [req.params.id, sid]);
  else await query('DELETE FROM activity_sections WHERE activity_id=$1', [req.params.id]);
  const left = (await query('SELECT COUNT(*)::int AS n FROM activity_sections WHERE activity_id=$1', [req.params.id])).rows[0].n;
  if (!left) await query('UPDATE activities SET is_published=false WHERE id=$1', [req.params.id]);
  res.json({ ok: true });
}));

router.put('/:id/release', wrap(async (req, res) => {
  const release = z.boolean().parse(req.body.release);
  await query('UPDATE activities SET release_scores=$1 WHERE id=$2', [release, req.params.id]);
  res.json({ ok: true });
}));

// ----- Submissions & grading -----
router.get('/:id/submissions', wrap(async (req, res) => {
  const { rows } = await query(
    `SELECT sb.id, sb.status, sb.submitted_at, sb.total_score, sb.max_score, sb.needs_review, sb.graded_at,
            u.id AS student_id, u.first_name, u.middle_name, u.last_name, u.email, s.name AS section_name
     FROM submissions sb JOIN users u ON u.id=sb.student_id LEFT JOIN sections s ON s.id=u.section_id
     WHERE sb.activity_id=$1 ORDER BY s.name, u.last_name`, [req.params.id]);
  res.json(rows);
}));

router.get('/submissions/:sid', wrap(async (req, res) => {
  const sb = (await query(
    `SELECT sb.*, u.first_name, u.last_name, u.email FROM submissions sb JOIN users u ON u.id=sb.student_id WHERE sb.id=$1`, [req.params.sid])).rows[0];
  if (!sb) throw new HttpError(404, 'Submission not found');
  const { rows } = await query(
    `SELECT q.id AS question_id, q.qtype, q.prompt, q.choices, q.answer_key, q.points, a.response, a.score, a.feedback, a.graded_manually
     FROM questions q LEFT JOIN answers a ON a.question_id=q.id AND a.submission_id=$1
     WHERE q.activity_id=$2 ORDER BY q.position`, [sb.id, sb.activity_id]);
  res.json({
    id: sb.id, activityId: sb.activity_id, status: sb.status, feedback: sb.feedback, totalScore: Number(sb.total_score), maxScore: Number(sb.max_score),
    student: { firstName: sb.first_name, lastName: sb.last_name, email: sb.email },
    answers: rows.map((r) => ({ questionId: r.question_id, qtype: r.qtype, prompt: r.prompt, choices: r.choices, answerKey: r.answer_key, points: Number(r.points),
      response: r.response, score: r.score == null ? null : Number(r.score), feedback: r.feedback, gradedManually: r.graded_manually })),
  });
}));

router.put('/submissions/:sid/grade', wrap(async (req, res) => {
  const d = z.object({
    feedback: z.string().trim().max(3000).optional().default(''),
    answers: z.array(z.object({ questionId: z.number().int(), score: z.coerce.number().min(0), feedback: z.string().max(2000).optional().default('') })),
  }).parse(req.body);
  const sb = (await query('SELECT * FROM submissions WHERE id=$1', [req.params.sid])).rows[0];
  if (!sb) throw new HttpError(404, 'Submission not found');
  if (sb.status !== 'submitted') throw new HttpError(400, 'This submission has not been submitted yet');
  const qpts = Object.fromEntries((await query('SELECT id, points FROM questions WHERE activity_id=$1', [sb.activity_id])).rows.map((q) => [q.id, Number(q.points)]));
  for (const a of d.answers) {
    if (!(a.questionId in qpts)) throw new HttpError(400, 'Question does not belong to this activity');
    if (a.score > qpts[a.questionId]) throw new HttpError(400, `Score cannot exceed ${qpts[a.questionId]} points for a question`);
    await query(
      `INSERT INTO answers (submission_id, question_id, score, graded_manually, feedback) VALUES ($1,$2,$3,true,$4)
       ON CONFLICT (submission_id, question_id) DO UPDATE SET score=$3, graded_manually=true, feedback=$4`,
      [sb.id, a.questionId, a.score, a.feedback]);
  }
  const tot = (await query('SELECT COALESCE(SUM(score),0) AS s FROM answers WHERE submission_id=$1', [sb.id])).rows[0].s;
  await query('UPDATE submissions SET total_score=$1, manual_score=$1, needs_review=false, feedback=$2, graded_at=now() WHERE id=$3', [tot, d.feedback, sb.id]);
  res.json({ totalScore: Number(tot) });
}));

module.exports = router;
