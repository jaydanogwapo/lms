const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { z } = require('zod');
const { query } = require('../db');
const { wrap, HttpError } = require('../middleware/errors');
const { requireAuth, requireStaff } = require('../middleware/auth');
const { extractText, allowedExtensions } = require('../services/extract');
const { generateQuestions, TYPES } = require('../services/ai');
const { notifySections, esc } = require('../services/mailer');

const router = express.Router();
router.use(requireAuth);

const UPLOAD_DIR = path.join(__dirname, '..', '..', 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (_req, file, cb) => cb(null, crypto.randomBytes(16).toString('hex') + path.extname(file.originalname).toLowerCase()),
  }),
  limits: { fileSize: Number(process.env.MAX_UPLOAD_MB || 20) * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!allowedExtensions.includes(ext)) return cb(new HttpError(400, `Unsupported file type. Allowed: ${allowedExtensions.join(', ')}`));
    cb(null, true);
  },
});

const LEVELS = ['beginner', 'intermediate', 'advanced'];
const levelSchema = z.enum(LEVELS);

// ----- Staff: list / upload / edit / delete -----
router.get('/', requireStaff, wrap(async (_req, res) => {
  const { rows } = await query(
    `SELECT m.id, m.title, m.description, m.level, m.original_name, m.size_bytes, m.created_at, m.course_id, c.title AS course_title,
            (SELECT COALESCE(json_agg(json_build_object('id', s.id, 'name', s.name) ORDER BY s.name), '[]')
               FROM lesson_sections ls JOIN sections s ON s.id = ls.section_id WHERE ls.material_id = m.id) AS sections,
            (length(COALESCE(m.extracted_text,'')) > 0) AS has_text
     FROM materials m LEFT JOIN courses c ON c.id = m.course_id ORDER BY m.created_at DESC`);
  res.json(rows);
}));

router.post('/', requireStaff, upload.single('file'), wrap(async (req, res) => {
  if (!req.file) throw new HttpError(400, 'Please choose a file to upload');
  const f = req.file;
  try {
    const d = z.object({
      title: z.string().trim().min(1).max(160),
      description: z.string().trim().max(1000).optional().default(''),
      level: levelSchema.default('beginner'),
      courseId: z.coerce.number().int().positive().optional(),
    }).parse(req.body);
    const ext = path.extname(f.originalname).toLowerCase();
    let text;
    try { text = await extractText(f.path, ext); }
    catch (e) { throw new HttpError(422, `Could not read this file: ${e.message}`); }
    const { rows } = await query(
      `INSERT INTO materials (course_id, title, description, level, original_name, stored_name, mime_type, size_bytes, extracted_text, uploaded_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id, title, level`,
      [d.courseId || null, d.title, d.description, d.level, f.originalname, f.filename, f.mimetype, f.size, text, req.user.id]);
    res.status(201).json({ ...rows[0], extractedChars: text.length });
  } catch (e) {
    fs.unlink(f.path, () => {});
    throw e;
  }
}));

router.put('/:id', requireStaff, wrap(async (req, res) => {
  const d = z.object({
    title: z.string().trim().min(1).max(160), description: z.string().trim().max(1000).optional().default(''),
    level: levelSchema, courseId: z.coerce.number().int().positive().nullable().optional(),
  }).parse(req.body);
  const { rows } = await query(
    'UPDATE materials SET title=$1, description=$2, level=$3, course_id=$4 WHERE id=$5 RETURNING id',
    [d.title, d.description, d.level, d.courseId || null, req.params.id]);
  if (!rows[0]) throw new HttpError(404, 'Material not found');
  res.json({ ok: true });
}));

router.delete('/:id', requireStaff, wrap(async (req, res) => {
  const { rows } = await query('DELETE FROM materials WHERE id=$1 RETURNING stored_name', [req.params.id]);
  if (!rows[0]) throw new HttpError(404, 'Material not found');
  fs.unlink(path.join(UPLOAD_DIR, rows[0].stored_name), () => {});
  res.json({ ok: true });
}));

// ----- Publish as lesson -----
router.post('/:id/publish', requireStaff, wrap(async (req, res) => {
  const d = z.object({ sectionIds: z.array(z.number().int().positive()).min(1), notify: z.boolean().optional().default(true) }).parse(req.body);
  const m = (await query('SELECT id, title, description, level FROM materials WHERE id=$1', [req.params.id])).rows[0];
  if (!m) throw new HttpError(404, 'Material not found');
  const added = [];
  for (const sid of d.sectionIds) {
    const r = await query(
      `INSERT INTO lesson_sections (material_id, section_id) SELECT $1, id FROM sections WHERE id=$2
       ON CONFLICT DO NOTHING RETURNING section_id`, [m.id, sid]);
    if (r.rows[0]) added.push(sid);
  }
  if (d.notify && added.length) {
    notifySections({
      sectionIds: added, kind: 'lesson_published', refType: 'material', refId: m.id,
      subject: `New lesson: ${m.title}`, heading: 'A new lesson is available',
      bodyHtml: `<p><b>${esc(m.title)}</b> (${esc(m.level)})</p><p>${esc(m.description || 'Your teacher published a new lesson.')}</p>`,
      ctaPath: '/student/lessons',
    }).catch((e) => console.error('notify failed', e.message));
  }
  res.json({ published: added.length, alreadyPublished: d.sectionIds.length - added.length });
}));

router.post('/:id/unpublish', requireStaff, wrap(async (req, res) => {
  const sid = z.number().int().positive().parse(req.body.sectionId);
  await query('DELETE FROM lesson_sections WHERE material_id=$1 AND section_id=$2', [req.params.id, sid]);
  res.json({ ok: true });
}));

// ----- Download (staff any; students only if published to their section) -----
router.get('/:id/download', wrap(async (req, res) => {
  let sql = 'SELECT original_name, stored_name FROM materials WHERE id=$1';
  const params = [req.params.id];
  if (req.user.role === 'student') {
    sql = `SELECT m.original_name, m.stored_name FROM materials m
           JOIN lesson_sections ls ON ls.material_id=m.id AND ls.section_id=$2 WHERE m.id=$1`;
    params.push(req.user.section_id);
  }
  const m = (await query(sql, params)).rows[0];
  if (!m) throw new HttpError(404, 'File not found');
  res.download(path.join(UPLOAD_DIR, m.stored_name), m.original_name);
}));

// ----- AI question generation (returns a DRAFT; nothing is stored until the teacher saves it) -----
router.post('/:id/generate', requireStaff, wrap(async (req, res) => {
  const d = z.object({
    count: z.coerce.number().int().min(1).max(50),
    types: z.array(z.enum(TYPES)).min(1),
    difficulty: levelSchema,
    topic: z.string().trim().max(300).optional().default(''),
  }).parse(req.body);
  const m = (await query('SELECT extracted_text FROM materials WHERE id=$1', [req.params.id])).rows[0];
  if (!m) throw new HttpError(404, 'Material not found');
  try {
    const questions = await generateQuestions({ text: m.extracted_text || '', ...d });
    if (!questions.length) throw new HttpError(502, 'The AI did not return usable questions. Please try again.');
    res.json({ questions, requested: d.count });
  } catch (e) {
    if (e instanceof HttpError) throw e;
    if (e.status === 503) throw new HttpError(503, e.message);
    if (e.status && e.status < 500 && e.status !== 429 && e.status !== 401) throw new HttpError(e.status, e.message);
    if (e.status === 401) throw new HttpError(503, 'AI API key was rejected. Check ANTHROPIC_API_KEY.');
    if (e.status === 429) throw new HttpError(429, 'AI rate limit reached. Please wait a moment and try again.');
    if (e instanceof HttpError) throw e;
    console.error('AI error', e.message);
    throw new HttpError(502, 'The AI service failed. Please try again.');
  }
}));

// ----- Student: lessons for my section, grouped client-side by level -----
router.get('/mine/list', wrap(async (req, res) => {
  if (req.user.role !== 'student') throw new HttpError(403, 'Students only');
  const { rows } = await query(
    `SELECT m.id, m.title, m.description, m.level, m.original_name, m.size_bytes, ls.published_at, c.title AS course_title
     FROM lesson_sections ls JOIN materials m ON m.id = ls.material_id LEFT JOIN courses c ON c.id = m.course_id
     WHERE ls.section_id = $1 ORDER BY ls.published_at DESC`, [req.user.section_id]);
  res.json(rows);
}));

module.exports = router;
