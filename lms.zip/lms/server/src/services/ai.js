const Anthropic = require('@anthropic-ai/sdk');

const TYPES = ['multiple_choice', 'true_false', 'identification', 'enumeration', 'short_answer', 'essay'];
const MAX_CHARS = 60000;

const TOOL = {
  name: 'submit_questions',
  description: 'Submit the generated questions with answer keys.',
  input_schema: {
    type: 'object',
    properties: {
      questions: {
        type: 'array',
        items: {
          type: 'object',
          properties: {
            qtype: { type: 'string', enum: TYPES },
            prompt: { type: 'string', description: 'The question text.' },
            choices: { type: 'array', items: { type: 'string' }, description: 'Exactly 4 options for multiple_choice only. No letter prefixes.' },
            answer: { type: 'string', description: 'multiple_choice: the exact text of the correct choice. true_false: "True" or "False". identification/short_answer: the expected answer. essay: a grading rubric / key points. enumeration: leave empty and use answer_items.' },
            answer_items: { type: 'array', items: { type: 'string' }, description: 'enumeration only: the list of correct items.' },
          },
          required: ['qtype', 'prompt'],
        },
      },
    },
    required: ['questions'],
  },
};

let client;
function getClient() {
  if (!process.env.ANTHROPIC_API_KEY) {
    const e = new Error('AI is not configured. Set ANTHROPIC_API_KEY in the server .env file.');
    e.status = 503;
    throw e;
  }
  client = client || new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  return client;
}

function normalize(q) {
  if (!q || !TYPES.includes(q.qtype) || !q.prompt) return null;
  const out = { qtype: q.qtype, prompt: String(q.prompt).trim(), choices: null, answerKey: null, points: 1 };
  if (q.qtype === 'multiple_choice') {
    const choices = (q.choices || []).map((c) => String(c).trim()).filter(Boolean);
    if (choices.length < 2 || !q.answer) return null;
    const ans = String(q.answer).trim();
    const match = choices.find((c) => c.toLowerCase() === ans.toLowerCase());
    if (!match) return null;
    out.choices = choices; out.answerKey = match;
  } else if (q.qtype === 'true_false') {
    const a = String(q.answer || '').trim().toLowerCase();
    if (a !== 'true' && a !== 'false') return null;
    out.answerKey = a === 'true' ? 'True' : 'False';
  } else if (q.qtype === 'enumeration') {
    const items = (q.answer_items && q.answer_items.length ? q.answer_items : String(q.answer || '').split(/[,;\n]/)).map((s) => String(s).trim()).filter(Boolean);
    if (!items.length) return null;
    out.answerKey = items; out.points = items.length;
  } else {
    out.answerKey = String(q.answer || '').trim();
    if (q.qtype === 'essay') out.points = 5;
    if (!out.answerKey && q.qtype !== 'essay') return null;
  }
  return out;
}

async function callOnce({ text, count, types, difficulty, topic, existing }) {
  const typeList = types.join(', ');
  const system = [
    'You are an expert teacher who writes assessment questions strictly from provided learning material.',
    'Rules: use ONLY information found in the material; never add outside facts; make every question self-contained and unambiguous;',
    'multiple choice must have exactly 4 plausible options and one correct answer whose text exactly matches one option;',
    'spread questions across the requested types and across the material; no duplicate questions.',
    'Always respond by calling the submit_questions tool.',
  ].join(' ');
  const user = [
    `Generate exactly ${count} questions.`,
    `Allowed question types: ${typeList}. Distribute them roughly evenly.`,
    `Difficulty: ${difficulty} (beginner = recall/basic concepts; intermediate = understanding/application; advanced = analysis/problem solving).`,
    topic ? `Focus only on this topic/lesson coverage: ${topic}` : 'Cover the whole material.',
    existing?.length ? `Do not repeat these existing questions:\n- ${existing.join('\n- ')}` : '',
    '',
    '--- LEARNING MATERIAL START ---',
    text.slice(0, MAX_CHARS),
    '--- LEARNING MATERIAL END ---',
  ].filter(Boolean).join('\n');

  const msg = await getClient().messages.create({
    model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
    max_tokens: 8000,
    system,
    tools: [TOOL],
    tool_choice: { type: 'tool', name: TOOL.name },
    messages: [{ role: 'user', content: user }],
  });
  const block = msg.content.find((b) => b.type === 'tool_use');
  return ((block && block.input.questions) || []).map(normalize).filter(Boolean);
}

async function generateQuestions(opts) {
  const types = (opts.types || []).filter((t) => TYPES.includes(t));
  if (!types.length) throw Object.assign(new Error('Select at least one question type'), { status: 400 });
  if (!opts.text || opts.text.length < 50) throw Object.assign(new Error('Not enough text was extracted from this file to generate questions'), { status: 422 });
  let result = await callOnce({ ...opts, types });
  // One top-up pass if the model returned fewer valid questions than requested.
  if (result.length < opts.count) {
    const more = await callOnce({ ...opts, types, count: opts.count - result.length, existing: result.map((q) => q.prompt) });
    result = result.concat(more);
  }
  return result.slice(0, opts.count);
}

module.exports = { generateQuestions, TYPES };
