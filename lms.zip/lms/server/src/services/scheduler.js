const cron = require('node-cron');
const { query } = require('../db');
const { sendMail, layout, esc } = require('./mailer');

// Sends one reminder per student per activity when the deadline is within 24 hours and they have not submitted.
async function sendDeadlineReminders() {
  const { rows } = await query(
    `SELECT a.id AS activity_id, a.title, a.deadline, u.id AS user_id, u.first_name, u.email
     FROM activities a
     JOIN activity_sections x ON x.activity_id = a.id
     JOIN users u ON u.section_id = x.section_id AND u.role='student' AND u.is_active AND u.email_verified
     LEFT JOIN submissions sb ON sb.activity_id = a.id AND sb.student_id = u.id
     WHERE a.is_published AND a.deadline > now() AND a.deadline < now() + interval '24 hours'
       AND COALESCE(sb.status, 'not_started') <> 'submitted'
       AND NOT EXISTS (SELECT 1 FROM email_notifications n
                       WHERE n.kind='deadline_reminder' AND n.ref_type='activity' AND n.ref_id=a.id AND n.user_id=u.id)`);
  for (const r of rows) {
    const when = new Date(r.deadline).toLocaleString('en-PH', { timeZone: 'Asia/Manila', dateStyle: 'medium', timeStyle: 'short' });
    await sendMail({
      userId: r.user_id, to: r.email, kind: 'deadline_reminder', refType: 'activity', refId: r.activity_id,
      subject: `Deadline approaching: ${r.title}`,
      html: layout('Deadline approaching', `<p>Hi ${esc(r.first_name)},</p><p><b>${esc(r.title)}</b> is due on <b>${esc(when)}</b> and you have not submitted it yet.</p>`,
        'Open my activities', `${process.env.APP_URL}/student/activities`),
    });
  }
  return rows.length;
}

function startScheduler() {
  cron.schedule('*/30 * * * *', () => {
    sendDeadlineReminders().catch((e) => console.error('Reminder job failed', e.message));
  });
}

module.exports = { startScheduler, sendDeadlineReminders };
