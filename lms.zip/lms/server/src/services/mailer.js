const nodemailer = require('nodemailer');
const { query } = require('../db');

let transporter;
function getTransporter() {
  if (transporter) return transporter;
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) return null;
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 465),
    secure: String(process.env.SMTP_SECURE || 'true') === 'true',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
  });
  return transporter;
}

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function layout(title, bodyHtml, ctaLabel, ctaUrl) {
  return `<div style="font-family:Arial,sans-serif;background:#f3f4f6;padding:24px">
  <div style="max-width:560px;margin:auto;background:#fff;border-radius:12px;overflow:hidden;border:1px solid #e5e7eb">
    <div style="background:#1d4ed8;color:#fff;padding:18px 24px;font-size:18px;font-weight:bold">${esc(title)}</div>
    <div style="padding:24px;color:#1f2937;font-size:15px;line-height:1.5">${bodyHtml}
      ${ctaUrl ? `<p style="margin-top:24px"><a href="${esc(ctaUrl)}" style="background:#1d4ed8;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;display:inline-block">${esc(ctaLabel)}</a></p>` : ''}
    </div>
    <div style="padding:12px 24px;font-size:12px;color:#6b7280;background:#f9fafb">Sent by your school's Learning Management System.</div>
  </div></div>`;
}

// Sends one email and records the outcome in email_notifications. Never throws.
async function sendMail({ userId = null, to, subject, html, kind, refType = null, refId = null }) {
  let status = 'sent';
  let error = null;
  const t = getTransporter();
  if (!t) {
    status = 'failed';
    error = 'SMTP is not configured';
  } else {
    try {
      await t.sendMail({ from: process.env.MAIL_FROM || process.env.SMTP_USER, to, subject, html });
    } catch (e) {
      status = 'failed';
      error = e.message;
      console.error('Email failed for', to, e.message);
    }
  }
  try {
    await query(
      `INSERT INTO email_notifications (user_id, to_email, kind, subject, ref_type, ref_id, status, error)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [userId, to, kind, subject, refType, refId, status, error]);
  } catch (e) { console.error('Could not log email', e.message); }
  return status === 'sent';
}

// Notifies every verified, active student of the given sections. Runs in the background.
async function notifySections({ sectionIds, kind, subject, heading, bodyHtml, refType, refId, ctaPath }) {
  if (!sectionIds.length) return 0;
  const { rows } = await query(
    `SELECT id, first_name, email FROM users
     WHERE role='student' AND is_active AND email_verified AND section_id = ANY($1::int[])`, [sectionIds]);
  const url = `${process.env.APP_URL}${ctaPath || '/student'}`;
  for (const s of rows) {
    await sendMail({
      userId: s.id, to: s.email, subject, kind, refType, refId,
      html: layout(heading, `<p>Hi ${esc(s.first_name)},</p>${bodyHtml}`, 'Open my dashboard', url),
    });
  }
  return rows.length;
}

module.exports = { sendMail, notifySections, layout, esc };
