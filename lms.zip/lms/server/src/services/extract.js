const path = require('path');
const fs = require('fs');
const AdmZip = require('adm-zip');
const mammoth = require('mammoth');
const pdfParse = require('pdf-parse');
const WordExtractor = require('word-extractor');

const ALLOWED = {
  '.pdf': 'pdf', '.docx': 'docx', '.doc': 'doc', '.pptx': 'pptx', '.ppt': 'ppt',
  '.txt': 'text', '.md': 'text', '.csv': 'text', '.rtf': 'rtf', '.html': 'html', '.htm': 'html',
};
const allowedExtensions = Object.keys(ALLOWED);

// Verify the file's real content matches its extension (not just the name).
function sniffOk(kind, buf) {
  const head = buf.subarray(0, 8);
  if (kind === 'pdf') return buf.subarray(0, 5).toString() === '%PDF-';
  if (kind === 'docx' || kind === 'pptx') return head[0] === 0x50 && head[1] === 0x4b; // PK zip
  if (kind === 'doc' || kind === 'ppt') return head[0] === 0xd0 && head[1] === 0xcf && head[2] === 0x11 && head[3] === 0xe0;
  if (kind === 'rtf') return buf.subarray(0, 5).toString() === '{\\rtf';
  // text-like: reject binary
  return !buf.subarray(0, 4096).includes(0);
}

const decodeXml = (s) => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');

function pptxText(buf) {
  const zip = new AdmZip(buf);
  const slides = zip.getEntries()
    .filter((e) => /^ppt\/slides\/slide\d+\.xml$/.test(e.entryName))
    .sort((a, b) => parseInt(a.entryName.match(/(\d+)\.xml/)[1], 10) - parseInt(b.entryName.match(/(\d+)\.xml/)[1], 10));
  return slides.map((e, i) => {
    const xml = e.getData().toString('utf8');
    const paras = xml.split(/<\/a:p>/).map((p) => [...p.matchAll(/<a:t[^>]*>([^<]*)<\/a:t>/g)].map((m) => decodeXml(m[1])).join('')).filter(Boolean);
    return `Slide ${i + 1}:\n${paras.join('\n')}`;
  }).join('\n\n');
}

// Legacy .ppt is a binary format; this is a best-effort scan for readable text runs.
function pptLegacyText(buf) {
  const utf16 = buf.toString('utf16le').match(/[\p{L}\p{N}][\p{L}\p{N}\s.,;:'"()\-–?!%/]{20,}/gu) || [];
  const ascii = buf.toString('latin1').match(/[A-Za-z0-9][A-Za-z0-9\s.,;:'"()\-?!%/]{25,}/g) || [];
  return [...new Set([...utf16, ...ascii])].join('\n');
}

async function extractText(filePath, ext) {
  const kind = ALLOWED[ext];
  const buf = fs.readFileSync(filePath);
  if (!kind) throw new Error('Unsupported file type');
  if (!sniffOk(kind, buf)) throw new Error('File content does not match its extension');
  let text = '';
  switch (kind) {
    case 'pdf': text = (await pdfParse(buf)).text; break;
    case 'docx': text = (await mammoth.extractRawText({ buffer: buf })).value; break;
    case 'doc': text = (await new WordExtractor().extract(filePath)).getBody(); break;
    case 'pptx': text = pptxText(buf); break;
    case 'ppt': text = pptLegacyText(buf); break;
    case 'rtf': text = buf.toString('utf8').replace(/\\'[0-9a-f]{2}/gi, ' ').replace(/\{[^}]*\}|\\[a-z]+-?\d* ?/gi, ' '); break;
    case 'html': text = buf.toString('utf8').replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' '); break;
    default: text = buf.toString('utf8');
  }
  return text.replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
}

module.exports = { extractText, allowedExtensions, ALLOWED };
