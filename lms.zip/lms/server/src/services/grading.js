// Grading helpers. Returns { score, needsReview } for one answer.
const norm = (s) => String(s ?? '').toLowerCase().replace(/[.,;:!?'"()]/g, '').replace(/\s+/g, ' ').trim();

function autoGrade(q, response) {
  const pts = Number(q.points);
  const key = q.answer_key;
  if (response === undefined || response === null || response === '' || (Array.isArray(response) && !response.length)) {
    return { score: 0, needsReview: false };
  }
  switch (q.qtype) {
    case 'multiple_choice':
    case 'true_false':
      return { score: norm(response) === norm(key) ? pts : 0, needsReview: false };
    case 'identification':
    case 'short_answer':
      // Exact (normalized) match is auto-credited; anything else goes to the teacher.
      if (norm(response) === norm(key)) return { score: pts, needsReview: false };
      return { score: 0, needsReview: q.qtype === 'short_answer' };
    case 'enumeration': {
      const given = (Array.isArray(response) ? response : String(response).split(/[\n,;]/)).map(norm).filter(Boolean);
      const keys = (Array.isArray(key) ? key : [key]).map(norm);
      const hits = new Set(given.filter((g) => keys.includes(g)));
      return { score: keys.length ? Math.round((hits.size / keys.length) * pts * 100) / 100 : 0, needsReview: false };
    }
    case 'essay':
      return { score: 0, needsReview: true };
    default:
      return { score: 0, needsReview: false };
  }
}

module.exports = { autoGrade, norm };
