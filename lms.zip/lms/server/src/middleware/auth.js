const jwt = require('jsonwebtoken');
const { query } = require('../db');

const COOKIE = 'lms_token';

function signToken(user) {
  return jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '8h' });
}

function setAuthCookie(res, token) {
  res.cookie(COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    maxAge: 8 * 60 * 60 * 1000,
  });
}

function clearAuthCookie(res) {
  res.clearCookie(COOKIE);
}

// Loads the current user from the DB on every request so deactivation / section moves apply immediately.
async function requireAuth(req, res, next) {
  try {
    const token = req.cookies[COOKIE];
    if (!token) return res.status(401).json({ error: 'Not authenticated' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const { rows } = await query(
      `SELECT id, role, first_name, middle_name, last_name, email, email_verified, section_id, is_active
       FROM users WHERE id = $1`, [payload.id]);
    const user = rows[0];
    if (!user || !user.is_active) return res.status(401).json({ error: 'Account not available' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired session' });
  }
}

const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ error: 'You do not have permission to do that' });
  }
  next();
};

const requireStaff = requireRole('admin', 'teacher');
const requireAdmin = requireRole('admin');
const requireStudent = requireRole('student');

module.exports = { signToken, setAuthCookie, clearAuthCookie, requireAuth, requireRole, requireStaff, requireAdmin, requireStudent };
