const { ZodError } = require('zod');

// Wraps async route handlers so rejections reach the error handler.
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function errorHandler(err, req, res, _next) {
  if (err instanceof ZodError) {
    return res.status(400).json({ error: err.issues.map((i) => `${i.path.join('.')}: ${i.message}`).join('; ') });
  }
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ error: `File too large (max ${process.env.MAX_UPLOAD_MB || 20} MB)` });
  }
  if (err.code === '23505') return res.status(409).json({ error: 'That value already exists' });
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  // HttpError messages are written for users, so they are always safe to show.
  const show = status < 500 || err instanceof HttpError;
  res.status(status).json({ error: show ? err.message : 'Something went wrong on the server' });
}

module.exports = { wrap, HttpError, errorHandler };
