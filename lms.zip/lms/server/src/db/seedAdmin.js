require('dotenv').config();
const bcrypt = require('bcryptjs');
const { pool } = require('./index');

(async () => {
  const email = (process.env.ADMIN_EMAIL || '').toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password || password.length < 8) {
    console.error('Set ADMIN_EMAIL and ADMIN_PASSWORD (min 8 chars) in .env first.');
    process.exit(1);
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    await pool.query(
      `INSERT INTO users (role, first_name, last_name, email, password_hash, email_verified)
       VALUES ('admin', $1, $2, $3, $4, true)
       ON CONFLICT (email) DO UPDATE SET password_hash = EXCLUDED.password_hash, role='admin'`,
      [process.env.ADMIN_FIRST_NAME || 'System', process.env.ADMIN_LAST_NAME || 'Administrator', email, hash]
    );
    console.log(`Admin account ready: ${email}`);
  } catch (e) {
    console.error('Seed failed:', e.message);
    process.exitCode = 1;
  } finally {
    await pool.end();
  }
})();
