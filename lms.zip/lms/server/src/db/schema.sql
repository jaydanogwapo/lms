-- AI-Powered LMS database schema (PostgreSQL)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN
  CREATE TYPE user_role AS ENUM ('admin', 'teacher', 'student');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE course_level AS ENUM ('beginner', 'intermediate', 'advanced');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS sections (
  id          SERIAL PRIMARY KEY,
  name        TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id              SERIAL PRIMARY KEY,
  role            user_role NOT NULL,
  first_name      TEXT NOT NULL,
  middle_name     TEXT,
  last_name       TEXT NOT NULL,
  email           TEXT NOT NULL UNIQUE,
  password_hash   TEXT NOT NULL,
  email_verified  BOOLEAN NOT NULL DEFAULT false,
  section_id      INTEGER REFERENCES sections(id) ON DELETE SET NULL,
  is_active       BOOLEAN NOT NULL DEFAULT true,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);
CREATE INDEX IF NOT EXISTS idx_users_section ON users(section_id);

CREATE TABLE IF NOT EXISTS email_verifications (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL,
  expires_at  TIMESTAMPTZ NOT NULL,
  used_at     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_emailver_hash ON email_verifications(token_hash);

CREATE TABLE IF NOT EXISTS courses (
  id          SERIAL PRIMARY KEY,
  title       TEXT NOT NULL,
  description TEXT,
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Learning materials (uploaded files). Extracted text kept for AI generation.
CREATE TABLE IF NOT EXISTS materials (
  id             SERIAL PRIMARY KEY,
  course_id      INTEGER REFERENCES courses(id) ON DELETE SET NULL,
  title          TEXT NOT NULL,
  description    TEXT,
  level          course_level NOT NULL DEFAULT 'beginner',
  original_name  TEXT NOT NULL,
  stored_name    TEXT NOT NULL,
  mime_type      TEXT,
  size_bytes     INTEGER NOT NULL,
  extracted_text TEXT,
  uploaded_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Lessons: a material published to sections
CREATE TABLE IF NOT EXISTS lesson_sections (
  material_id  INTEGER NOT NULL REFERENCES materials(id) ON DELETE CASCADE,
  section_id   INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  published_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (material_id, section_id)
);

-- Questionnaires: generated ONCE and stored; every student reads the same rows.
CREATE TABLE IF NOT EXISTS activities (
  id            SERIAL PRIMARY KEY,
  course_id     INTEGER REFERENCES courses(id) ON DELETE SET NULL,
  material_id   INTEGER REFERENCES materials(id) ON DELETE SET NULL,
  title         TEXT NOT NULL,
  instructions  TEXT,
  level         course_level NOT NULL DEFAULT 'beginner',
  deadline      TIMESTAMPTZ,
  is_published  BOOLEAN NOT NULL DEFAULT false,
  published_at  TIMESTAMPTZ,
  release_scores BOOLEAN NOT NULL DEFAULT false,
  created_by    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS activity_sections (
  activity_id INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  section_id  INTEGER NOT NULL REFERENCES sections(id) ON DELETE CASCADE,
  PRIMARY KEY (activity_id, section_id)
);

CREATE TABLE IF NOT EXISTS questions (
  id           SERIAL PRIMARY KEY,
  activity_id  INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  position     INTEGER NOT NULL DEFAULT 0,
  qtype        TEXT NOT NULL CHECK (qtype IN
                 ('multiple_choice','true_false','identification','enumeration','short_answer','essay')),
  prompt       TEXT NOT NULL,
  choices      JSONB,            -- array of strings for multiple_choice
  answer_key   JSONB,            -- string | array (enumeration items)
  points       NUMERIC(6,2) NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_questions_activity ON questions(activity_id, position);

CREATE TABLE IF NOT EXISTS submissions (
  id            SERIAL PRIMARY KEY,
  activity_id   INTEGER NOT NULL REFERENCES activities(id) ON DELETE CASCADE,
  student_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status        TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress','submitted')),
  submitted_at  TIMESTAMPTZ,
  auto_score    NUMERIC(8,2) NOT NULL DEFAULT 0,
  manual_score  NUMERIC(8,2) NOT NULL DEFAULT 0,
  total_score   NUMERIC(8,2) NOT NULL DEFAULT 0,
  max_score     NUMERIC(8,2) NOT NULL DEFAULT 0,
  needs_review  BOOLEAN NOT NULL DEFAULT false,
  feedback      TEXT,
  graded_at     TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (activity_id, student_id)
);

CREATE TABLE IF NOT EXISTS answers (
  id             SERIAL PRIMARY KEY,
  submission_id  INTEGER NOT NULL REFERENCES submissions(id) ON DELETE CASCADE,
  question_id    INTEGER NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  response       JSONB,
  score          NUMERIC(6,2),
  graded_manually BOOLEAN NOT NULL DEFAULT false,
  feedback       TEXT,
  UNIQUE (submission_id, question_id)
);

CREATE TABLE IF NOT EXISTS email_notifications (
  id          SERIAL PRIMARY KEY,
  user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  to_email    TEXT NOT NULL,
  kind        TEXT NOT NULL,
  subject     TEXT NOT NULL,
  ref_type    TEXT,
  ref_id      INTEGER,
  status      TEXT NOT NULL DEFAULT 'sent',
  error       TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notif_ref ON email_notifications(kind, ref_type, ref_id);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
