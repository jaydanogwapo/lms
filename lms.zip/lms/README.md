# AI-Powered Learning Management System

Teachers upload lessons (PDF, Word, PowerPoint, TXT…), generate quizzes with AI, publish them to sections, and every student in a section gets the **identical stored questionnaire**. Students are notified by Gmail.

**Stack:** React + Vite + Tailwind (client) · Node.js + Express (server) · PostgreSQL · Anthropic Claude API (question generation) · Nodemailer (Gmail SMTP).

```
lms/
  server/   Express API, DB schema, AI + email services
  client/   React app (teacher/admin dashboard and student dashboard)
```

## 1. Requirements
- Node.js 18+ and npm
- PostgreSQL 13+
- An Anthropic API key (for AI quiz generation)
- A Gmail account with an App Password (for email)

## 2. Install
```bash
# create the database
sudo -u postgres psql -c "CREATE USER lms_user WITH PASSWORD 'change_me';"
sudo -u postgres psql -c "CREATE DATABASE lms OWNER lms_user;"

# install dependencies
npm run install:all

# configure
cp server/.env.example server/.env      # then edit server/.env (see below)

# create tables and the first admin account
npm run migrate
npm run seed-admin
```

## 3. Run
**Development** (two terminals):
```bash
npm run dev:server     # API on http://localhost:4000
npm run dev:client     # app on http://localhost:5173
```
Open http://localhost:5173 and log in as the admin from `ADMIN_EMAIL` / `ADMIN_PASSWORD`.

**Production** (one server):
```bash
npm run build          # builds client/dist
NODE_ENV=production npm start
```
The server serves the built client. Set `APP_URL` to your public URL (it is used in emails and CORS), and run behind HTTPS.

## 4. Connect the AI API
1. Create a key at https://console.anthropic.com.
2. In `server/.env` set `ANTHROPIC_API_KEY=sk-ant-...`. Optionally set `ANTHROPIC_MODEL` to any available Claude model.
3. Restart the server. Keys live only on the server and are never sent to the browser.

If the key is missing, uploads and everything else still work; the Generate button shows a clear "AI is not configured" message.

## 5. Connect Gmail
1. Turn on 2-Step Verification for the sending Google account.
2. Create an App Password at https://myaccount.google.com/apppasswords.
3. In `server/.env`:
   ```
   SMTP_HOST=smtp.gmail.com
   SMTP_PORT=465
   SMTP_SECURE=true
   SMTP_USER=yourschool@gmail.com
   SMTP_PASS=<16-character app password>
   MAIL_FROM="LMS Notifications <yourschool@gmail.com>"
   ```
4. Restart. Any SMTP provider (SendGrid, Mailgun, SES…) also works by changing the host, port and credentials.

Gmail has daily sending limits (about 500/day for regular accounts); use a transactional provider for large schools.

Every email, successful or failed, is recorded in the `email_notifications` table. Verification emails can be re-sent from the student login page.

## 6. How it works
- **Roles:** `admin` (everything, including sections and staff accounts), `teacher` (materials, AI quizzes, publishing, grading, reports), `student`. Staff and students use separate login pages and separate dashboards, and the server enforces roles on every endpoint.
- **Registration:** students give first/middle/last name, a `@gmail.com` address, password and section. They must click the emailed verification link (valid 24h) before they can log in.
- **Sections:** admins create, rename, delete sections and transfer students. Students are grouped by their section automatically; students only ever see lessons and activities published to their own section.
- **AI generation:** upload a file → text is extracted → choose number of questions, types, difficulty and topic → the AI returns a draft. Preview, edit questions, choices and the answer key, delete or add questions, regenerate, then save. Nothing is shown to students until you publish.
- **Identical questionnaires:** a saved activity's questions and answer key are rows in the database. All students read those same rows; nothing is generated per student. Students never receive the answer key.
- **Levels:** materials and activities are tagged Beginner / Intermediate / Advanced. Students see lessons grouped by level.
- **Grading:** multiple choice, true/false, identification and enumeration (partial credit) are auto-graded. Essays and non-matching short answers are flagged "needs review" for the teacher. Scores and feedback are hidden until the teacher clicks **Release scores**.
- **Deadlines:** once past, the student view becomes read-only. A background job (every 30 minutes) emails students who have not submitted an activity due within 24 hours (once per student per activity).
- **Notifications sent:** new lesson, new activity, updated activity, deadline approaching, email verification.
- **Reports:** dashboard analytics plus Excel/PDF export for school-wide overview and per-activity results.

## 7. Security notes
bcrypt password hashing · httpOnly SameSite session cookie (JWT, 8h) · role checks on all routes · zod server-side validation · rate-limited auth endpoints · Helmet headers · uploads limited by extension, size (`MAX_UPLOAD_MB`) and file signature, stored under random names outside the web root · students can download only files published to their section · secrets only in `server/.env`.

For production also: serve over HTTPS, set `NODE_ENV=production`, use a long random `JWT_SECRET`, and back up the database and `server/uploads/`.

## 8. Limits to know about
- Legacy `.ppt` files are read on a best-effort basis; `.pptx` is recommended. Scanned PDFs (images only) contain no text and cannot be analyzed without OCR.
- Only the first ~60,000 characters of a material are sent to the AI per generation; use the **Topic** field to target a specific part of long documents.
- Always review AI-generated questions and the answer key before publishing.

## 9. Database
Schema: `server/src/db/schema.sql` (users, sections, courses, materials, lesson_sections, activities, activity_sections, questions, submissions, answers, email_verifications, email_notifications, settings). Re-running `npm run migrate` is safe.
