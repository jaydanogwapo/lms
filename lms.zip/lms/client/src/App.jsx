import { Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth';
import { PageLoader, ToastProvider } from './ui';
import { Landing, Register, StaffLogin, StudentLogin, VerifyEmail } from './pages/Public';
import StaffLayout from './pages/staff/StaffLayout';
import Dashboard from './pages/staff/Dashboard';
import Sections from './pages/staff/Sections';
import Students from './pages/staff/Students';
import Teachers from './pages/staff/Teachers';
import Materials from './pages/staff/Materials';
import Generator from './pages/staff/Generator';
import Activities from './pages/staff/Activities';
import Grading from './pages/staff/Grading';
import StudentLayout from './pages/student/StudentLayout';
import StudentHome from './pages/student/Home';
import Lessons from './pages/student/Lessons';
import MyActivities from './pages/student/MyActivities';
import TakeActivity from './pages/student/TakeActivity';

// Keeps the two interfaces fully separate: each area only admits its own roles.
function Guard({ roles, children }) {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (!user) return <Navigate to="/" replace />;
  if (!roles.includes(user.role)) return <Navigate to={user.role === 'student' ? '/student' : '/staff'} replace />;
  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/student-login" element={<StudentLogin />} />
          <Route path="/staff-login" element={<StaffLogin />} />
          <Route path="/register" element={<Register />} />
          <Route path="/verify-email" element={<VerifyEmail />} />

          <Route path="/staff" element={<Guard roles={['admin', 'teacher']}><StaffLayout /></Guard>}>
            <Route index element={<Dashboard />} />
            <Route path="sections" element={<Sections />} />
            <Route path="students" element={<Students />} />
            <Route path="teachers" element={<Guard roles={['admin']}><Teachers /></Guard>} />
            <Route path="materials" element={<Materials />} />
            <Route path="generate/:materialId" element={<Generator />} />
            <Route path="activities" element={<Activities />} />
            <Route path="activities/:id/edit" element={<Generator editing />} />
            <Route path="activities/:id/grading" element={<Grading />} />
          </Route>

          <Route path="/student" element={<Guard roles={['student']}><StudentLayout /></Guard>}>
            <Route index element={<StudentHome />} />
            <Route path="lessons" element={<Lessons />} />
            <Route path="activities" element={<MyActivities />} />
            <Route path="activities/:id" element={<TakeActivity />} />
          </Route>

          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </ToastProvider>
    </AuthProvider>
  );
}
