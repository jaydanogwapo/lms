// Thin fetch wrapper: cookies are sent automatically, errors become Error(message).
async function request(method, url, body, isForm) {
  const opts = { method, credentials: 'include', headers: {} };
  if (body !== undefined) {
    if (isForm) opts.body = body;
    else { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  }
  const res = await fetch(`/api${url}`, opts);
  let data = null;
  try { data = await res.json(); } catch { /* no body */ }
  if (!res.ok) {
    const err = new Error(data?.error || `Request failed (${res.status})`);
    err.status = res.status;
    throw err;
  }
  return data;
}

export const api = {
  get: (u) => request('GET', u),
  post: (u, b) => request('POST', u, b ?? {}),
  put: (u, b) => request('PUT', u, b ?? {}),
  del: (u) => request('DELETE', u),
  upload: (u, formData) => request('POST', u, formData, true),
};

export const fullName = (u) => [u.first_name ?? u.firstName, u.middle_name ?? u.middleName, u.last_name ?? u.lastName].filter(Boolean).join(' ');
export const fmtDate = (d) => (d ? new Date(d).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—');
export const fmtDay = (d) => (d ? new Date(d).toLocaleDateString(undefined, { dateStyle: 'medium' }) : '—');
export const LEVELS = ['beginner', 'intermediate', 'advanced'];
export const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : '');
export const QTYPES = [
  ['multiple_choice', 'Multiple Choice'], ['true_false', 'True or False'], ['identification', 'Identification'],
  ['enumeration', 'Enumeration'], ['short_answer', 'Short Answer'], ['essay', 'Essay'],
];
export const qtypeLabel = (t) => (QTYPES.find((x) => x[0] === t) || [t, t])[1];
