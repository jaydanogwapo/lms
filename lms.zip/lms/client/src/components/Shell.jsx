import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../auth';

// Shared shell: sidebar + top bar. Staff and student dashboards each pass their own nav.
export default function Shell({ nav, title, subtitle }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const out = async () => { await logout(); navigate('/'); };

  return (
    <div className="min-h-screen lg:flex">
      {open && <div className="fixed inset-0 z-30 bg-slate-900/40 lg:hidden" onClick={() => setOpen(false)} />}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 transform bg-brand-900 text-white transition-transform lg:static lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex h-16 items-center gap-3 px-5 text-lg font-bold">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/15 text-xl">🎓</span>
          <div className="leading-tight">{title}<div className="text-[11px] font-normal text-blue-200">{subtitle}</div></div>
        </div>
        <nav className="mt-2 space-y-1 px-3">
          {nav.map((n) => (
            <NavLink key={n.to} to={n.to} end={n.end} onClick={() => setOpen(false)}
              className={({ isActive }) => `flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${isActive ? 'bg-white text-brand-800' : 'text-blue-100 hover:bg-white/10'}`}>
              <span className="w-5 text-center">{n.icon}</span>{n.label}
              {n.badge ? <span className="ml-auto rounded-full bg-red-500 px-2 py-0.5 text-[11px] font-bold text-white">{n.badge}</span> : null}
            </NavLink>
          ))}
        </nav>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-200 bg-white px-4 sm:px-6">
          <button className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">☰</button>
          <div className="ml-auto flex items-center gap-3">
            <div className="hidden text-right sm:block">
              <div className="text-sm font-semibold text-slate-800">{user.firstName} {user.lastName}</div>
              <div className="text-xs capitalize text-slate-500">{user.role}</div>
            </div>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 font-bold text-brand-800">{user.firstName[0]}</div>
            <button className="btn-secondary btn-sm" onClick={out}>Log out</button>
          </div>
        </header>
        <main className="flex-1 p-4 sm:p-6"><div className="mx-auto max-w-6xl"><Outlet /></div></main>
      </div>
    </div>
  );
}

export function PageHeader({ title, children, sub }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div><h1 className="text-2xl font-bold">{title}</h1>{sub && <p className="text-sm text-slate-500">{sub}</p>}</div>
      <div className="flex flex-wrap gap-2">{children}</div>
    </div>
  );
}
