import { api } from '../../api';
import { Empty, ErrorNote, PageLoader, StatCard, Table, download, useLoad } from '../../ui';
import { PageHeader } from '../../components/Shell';

function Bar({ value, color = 'bg-brand-600' }) {
  return (
    <div className="flex items-center gap-2">
      <div className="h-2 w-full min-w-[80px] rounded-full bg-slate-100"><div className={`h-2 rounded-full ${color}`} style={{ width: `${Math.min(100, value)}%` }} /></div>
      <span className="w-12 text-right text-xs text-slate-600">{value}%</span>
    </div>
  );
}

export default function Dashboard() {
  const { data, loading, error } = useLoad(() => api.get('/reports/overview'));
  if (loading) return <PageLoader />;
  if (error) return <ErrorNote error={error} />;
  const c = data.counts;
  return (
    <>
      <PageHeader title="Analytics" sub="School-wide participation and performance">
        <button className="btn-secondary" onClick={() => download('/reports/export/overview.xlsx')}>⬇ Excel</button>
        <button className="btn-secondary" onClick={() => download('/reports/export/overview.pdf')}>⬇ PDF</button>
      </PageHeader>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon="🧑‍🎓" label="Registered students" value={c.students} />
        <StatCard icon="👩‍🏫" label="Teachers" value={c.teachers} />
        <StatCard icon="🏫" label="Sections" value={c.sections} />
        <StatCard icon="📚" label="Published lessons" value={c.lessons} />
        <StatCard icon="🧠" label="Generated quizzes" value={c.quizzes} sub={`${c.published_activities} published`} />
        <StatCard icon="🙋" label="Student participation" value={`${data.participationRate}%`} />
        <StatCard icon="✅" label="Completion rate" value={`${data.completionRate}%`} />
        <StatCard icon="⭐" label="Average score" value={`${c.avg_percent}%`} />
      </div>

      <h2 className="mb-3 mt-8 text-lg font-bold">Section performance</h2>
      {data.bySection.length === 0 ? <Empty title="No sections yet">Create a section to get started.</Empty> : (
        <Table head={['Section', 'Students', 'Submissions', 'Participation', 'Average score']}>
          {data.bySection.map((s) => (
            <tr key={s.id}><td className="td font-medium">{s.name}</td><td className="td">{s.students}</td><td className="td">{s.submissions}</td>
              <td className="td w-56"><Bar value={s.participation} /></td><td className="td w-56"><Bar value={s.avg_percent} color="bg-emerald-500" /></td></tr>
          ))}
        </Table>
      )}

      <h2 className="mb-3 mt-8 text-lg font-bold">Activity completion</h2>
      {data.byActivity.length === 0 ? <Empty title="No published activities yet" /> : (
        <Table head={['Activity', 'Level', 'Submitted', 'Completion', 'Average score']}>
          {data.byActivity.map((a) => (
            <tr key={a.id}><td className="td font-medium">{a.title}</td><td className="td capitalize">{a.level}</td><td className="td">{a.submitted}/{a.assigned}</td>
              <td className="td w-56"><Bar value={a.completion} /></td><td className="td w-56"><Bar value={a.avg_percent} color="bg-emerald-500" /></td></tr>
          ))}
        </Table>
      )}
    </>
  );
}
