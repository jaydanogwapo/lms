import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, LEVELS, QTYPES, cap, qtypeLabel } from '../../api';
import { Badge, Button, ErrorNote, Field, PageLoader, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';
import { SectionPicker } from './Materials';

const toLocalInput = (iso) => {
  if (!iso) return '';
  const d = new Date(iso);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};

const blank = (qtype) => ({
  qtype, prompt: '', points: qtype === 'essay' ? 5 : 1,
  choices: qtype === 'multiple_choice' ? ['', '', '', ''] : null,
  answerKey: qtype === 'enumeration' ? [''] : qtype === 'true_false' ? 'True' : '',
});

export default function Generator({ editing }) {
  const { materialId, id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const sections = useLoad(() => api.get('/admin/sections'));
  const [loading, setLoading] = useState(true);
  const [fatal, setFatal] = useState('');
  const [material, setMaterial] = useState(null);

  const [settings, setSettings] = useState({ count: 10, types: ['multiple_choice', 'true_false'], difficulty: 'beginner', topic: '' });
  const [meta, setMeta] = useState({ title: '', instructions: '', level: 'beginner', deadline: '', courseId: null, materialId: null });
  const [questions, setQuestions] = useState([]);
  const [activityId, setActivityId] = useState(editing ? Number(id) : null);
  const [published, setPublished] = useState(false);
  const [sel, setSel] = useState([]);
  const [notify, setNotify] = useState(true);
  const [genBusy, setGenBusy] = useState(false);
  const [saveBusy, setSaveBusy] = useState(false);
  const [err, setErr] = useState('');

  useEffect(() => {
    (async () => {
      try {
        if (editing) {
          const a = await api.get(`/activities/${id}`);
          setMeta({ title: a.title, instructions: a.instructions || '', level: a.level, deadline: toLocalInput(a.deadline), courseId: a.courseId, materialId: a.materialId });
          setQuestions(a.questions); setSel(a.sectionIds); setPublished(a.isPublished);
          setSettings((s) => ({ ...s, difficulty: a.level }));
        } else {
          const all = await api.get('/materials');
          const m = all.find((x) => x.id === Number(materialId));
          if (!m) throw new Error('Material not found');
          setMaterial(m);
          setMeta({ title: `${m.title} Quiz`, instructions: 'Read each question carefully and answer all items.', level: m.level, deadline: '', courseId: m.course_id, materialId: m.id });
          setSettings((s) => ({ ...s, difficulty: m.level }));
        }
      } catch (e) { setFatal(e.message); } finally { setLoading(false); }
    })();
  }, [editing, id, materialId]);

  const srcMaterialId = meta.materialId;

  const generate = async () => {
    if (questions.length && !window.confirm('Regenerating replaces the current questions. Continue?')) return;
    setErr(''); setGenBusy(true);
    try {
      const r = await api.post(`/materials/${srcMaterialId}/generate`, { ...settings, count: Number(settings.count) });
      setQuestions(r.questions);
      toast(r.questions.length < r.requested ? `Generated ${r.questions.length} of ${r.requested} questions` : `Generated ${r.questions.length} questions. Review them before saving.`);
    } catch (e) { setErr(e.message); } finally { setGenBusy(false); }
  };

  const toggleType = (t) => setSettings((s) => ({ ...s, types: s.types.includes(t) ? s.types.filter((x) => x !== t) : [...s.types, t] }));
  const upd = (i, patch) => setQuestions((qs) => qs.map((q, k) => (k === i ? { ...q, ...patch } : q)));
  const del = (i) => setQuestions((qs) => qs.filter((_, k) => k !== i));
  const move = (i, d) => setQuestions((qs) => { const a = [...qs]; const j = i + d; if (j < 0 || j >= a.length) return qs; [a[i], a[j]] = [a[j], a[i]]; return a; });

  const payload = () => ({
    title: meta.title, instructions: meta.instructions, level: meta.level,
    deadline: meta.deadline ? new Date(meta.deadline).toISOString() : null,
    courseId: meta.courseId || null, materialId: meta.materialId || null,
    questions: questions.map((q) => ({
      id: q.id, qtype: q.qtype, prompt: q.prompt, points: Number(q.points),
      choices: q.qtype === 'multiple_choice' ? q.choices.map((c) => c.trim()) : null,
      answerKey: q.qtype === 'enumeration' ? q.answerKey.map((x) => x.trim()).filter(Boolean) : q.qtype === 'essay' ? (q.answerKey || '') : q.answerKey,
    })),
  });

  const save = async () => {
    setErr('');
    if (!meta.title.trim()) return setErr('Give the activity a title');
    if (!questions.length) return setErr('Add or generate at least one question');
    setSaveBusy(true);
    try {
      let aid = activityId;
      if (aid) await api.put(`/activities/${aid}`, payload());
      else { const r = await api.post('/activities', payload()); aid = r.id; setActivityId(aid); }
      // reload so new questions get database ids (students must see exactly what is stored)
      const fresh = await api.get(`/activities/${aid}`);
      setQuestions(fresh.questions);
      toast('Saved. This exact questionnaire is stored and shared by every student in the assigned sections.');
      return aid;
    } catch (e) { setErr(e.message); return null; } finally { setSaveBusy(false); }
  };

  const publish = async () => {
    const aid = await save();
    if (!aid) return;
    setSaveBusy(true);
    try {
      const r = await api.post(`/activities/${aid}/publish`, { sectionIds: sel, notify });
      toast(`Published to ${r.published || 'the selected'} section(s)${notify && r.published ? '. Emails are being sent.' : ''}`);
      navigate('/staff/activities');
    } catch (e) { setErr(e.message); } finally { setSaveBusy(false); }
  };

  if (loading) return <PageLoader />;
  if (fatal) return <ErrorNote error={fatal} />;

  return (
    <>
      <PageHeader title={editing ? 'Edit activity' : 'AI quiz generator'} sub={material ? `Source: ${material.title}` : undefined}>
        {published && <Badge color="green">Published</Badge>}
      </PageHeader>

      {srcMaterialId && (
        <section className="card mb-5">
          <h2 className="mb-3 font-bold">1. Generation settings</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Number of questions"><input className="input" type="number" min={1} max={50} value={settings.count} onChange={(e) => setSettings({ ...settings, count: e.target.value })} /></Field>
            <Field label="Difficulty"><select className="input" value={settings.difficulty} onChange={(e) => setSettings({ ...settings, difficulty: e.target.value })}>{LEVELS.map((l) => <option key={l} value={l}>{cap(l)}</option>)}</select></Field>
            <Field label="Topic / lesson coverage" hint="Optional. Leave empty to cover everything."><input className="input" maxLength={300} value={settings.topic} onChange={(e) => setSettings({ ...settings, topic: e.target.value })} placeholder="e.g. Chapter 2: Photosynthesis" /></Field>
          </div>
          <div className="mt-4">
            <span className="label">Question types</span>
            <div className="flex flex-wrap gap-2">
              {QTYPES.map(([v, l]) => (
                <button key={v} type="button" onClick={() => toggleType(v)} className={`rounded-full border px-3 py-1.5 text-sm font-medium ${settings.types.includes(v) ? 'border-brand-600 bg-brand-600 text-white' : 'border-slate-300 bg-white text-slate-600'}`}>{l}</button>
              ))}
            </div>
          </div>
          <div className="mt-4 flex items-center gap-3">
            <Button onClick={generate} loading={genBusy} disabled={!settings.types.length || !settings.count}>{questions.length ? '🔄 Regenerate questions' : '✨ Generate questions'}</Button>
            {genBusy && <span className="text-sm text-slate-500">The AI is reading the material… this can take up to a minute.</span>}
          </div>
        </section>
      )}

      <section className="card mb-5">
        <h2 className="mb-3 font-bold">{srcMaterialId ? '2. ' : ''}Activity details</h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Title"><input className="input" value={meta.title} maxLength={160} onChange={(e) => setMeta({ ...meta, title: e.target.value })} /></Field>
          <Field label="Course level"><select className="input" value={meta.level} onChange={(e) => setMeta({ ...meta, level: e.target.value })}>{LEVELS.map((l) => <option key={l} value={l}>{cap(l)}</option>)}</select></Field>
          <Field label="Deadline (optional)"><input className="input" type="datetime-local" value={meta.deadline} onChange={(e) => setMeta({ ...meta, deadline: e.target.value })} /></Field>
          <div className="sm:col-span-2"><Field label="Instructions"><textarea className="input" rows={3} maxLength={5000} value={meta.instructions} onChange={(e) => setMeta({ ...meta, instructions: e.target.value })} /></Field></div>
        </div>
      </section>

      <section className="mb-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-bold">{srcMaterialId ? '3. ' : ''}Questions & answer key <span className="font-normal text-slate-500">({questions.length})</span></h2>
          <div className="flex items-center gap-2">
            <select className="input w-auto py-1.5 text-sm" value="" onChange={(e) => e.target.value && setQuestions([...questions, blank(e.target.value)])} aria-label="Add question">
              <option value="">+ Add question manually…</option>{QTYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
        </div>
        {questions.length === 0 && <div className="rounded-xl border border-dashed border-slate-300 bg-white p-8 text-center text-sm text-slate-500">No questions yet. Generate them with AI or add one manually.</div>}
        <div className="space-y-3">
          {questions.map((q, i) => <QuestionEditor key={q.id ?? `n${i}`} q={q} i={i} upd={upd} del={del} move={move} last={i === questions.length - 1} />)}
        </div>
      </section>

      <section className="card mb-5">
        <h2 className="mb-3 font-bold">Save & publish</h2>
        <p className="mb-3 text-sm text-slate-600">Saving stores this exact questionnaire in the database. Everyone in the selected sections receives the same questions, choices and instructions.</p>
        <SectionPicker sections={sections.data || []} selected={sel} onChange={setSel} />
        <label className="mt-4 flex items-center gap-2 text-sm"><input type="checkbox" checked={notify} onChange={(e) => setNotify(e.target.checked)} /> Email students when I publish</label>
        <div className="mt-3"><ErrorNote error={err} /></div>
        <div className="mt-4 flex flex-wrap justify-end gap-2">
          <Button variant="secondary" onClick={() => navigate('/staff/activities')}>Cancel</Button>
          <Button variant="secondary" onClick={async () => { const a = await save(); if (a && !editing) navigate('/staff/activities'); }} loading={saveBusy}>Save {published ? 'changes' : 'as draft'}</Button>
          <Button onClick={publish} loading={saveBusy} disabled={!sel.length}>{published ? 'Save & publish to selected sections' : 'Publish to selected sections'}</Button>
        </div>
      </section>
    </>
  );
}

function QuestionEditor({ q, i, upd, del, move, last }) {
  const setChoice = (k, v) => {
    const old = q.choices[k];
    const choices = q.choices.map((c, j) => (j === k ? v : c));
    upd(i, { choices, answerKey: q.answerKey === old ? v : q.answerKey });
  };
  const items = Array.isArray(q.answerKey) ? q.answerKey : [];
  return (
    <div className="card">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-brand-100 text-sm font-bold text-brand-800">{i + 1}</span>
        <Badge color="blue">{qtypeLabel(q.qtype)}</Badge>
        <label className="ml-auto flex items-center gap-1 text-xs text-slate-500">Points
          <input className="input w-16 py-1" type="number" min={0} step="0.5" value={q.points} onChange={(e) => upd(i, { points: e.target.value })} /></label>
        <button className="btn-secondary btn-sm" disabled={i === 0} onClick={() => move(i, -1)} aria-label="Move up">↑</button>
        <button className="btn-secondary btn-sm" disabled={last} onClick={() => move(i, 1)} aria-label="Move down">↓</button>
        <button className="btn-danger btn-sm" onClick={() => del(i)}>Delete</button>
      </div>
      <textarea className="input" rows={2} value={q.prompt} placeholder="Question" onChange={(e) => upd(i, { prompt: e.target.value })} />

      {q.qtype === 'multiple_choice' && (
        <div className="mt-3 space-y-2">
          <span className="label">Choices — select the correct one</span>
          {q.choices.map((c, k) => (
            <div key={k} className="flex items-center gap-2">
              <input type="radio" name={`ans${i}`} checked={c !== '' && q.answerKey === c} onChange={() => upd(i, { answerKey: c })} aria-label={`Correct answer ${k + 1}`} />
              <input className="input" value={c} placeholder={`Choice ${k + 1}`} onChange={(e) => setChoice(k, e.target.value)} />
              {q.choices.length > 2 && <button className="text-slate-400 hover:text-red-600" onClick={() => upd(i, { choices: q.choices.filter((_, j) => j !== k), answerKey: q.answerKey === c ? '' : q.answerKey })} aria-label="Remove choice">✕</button>}
            </div>
          ))}
          {q.choices.length < 8 && <button className="text-sm font-medium text-brand-700" onClick={() => upd(i, { choices: [...q.choices, ''] })}>+ Add choice</button>}
        </div>
      )}
      {q.qtype === 'true_false' && (
        <div className="mt-3 flex items-center gap-4 text-sm">
          <span className="label mb-0">Correct answer:</span>
          {['True', 'False'].map((v) => <label key={v} className="flex items-center gap-1"><input type="radio" name={`tf${i}`} checked={q.answerKey === v} onChange={() => upd(i, { answerKey: v })} />{v}</label>)}
        </div>
      )}
      {(q.qtype === 'identification' || q.qtype === 'short_answer') && (
        <div className="mt-3"><Field label="Answer key"><input className="input" value={typeof q.answerKey === 'string' ? q.answerKey : ''} onChange={(e) => upd(i, { answerKey: e.target.value })} /></Field></div>
      )}
      {q.qtype === 'enumeration' && (
        <div className="mt-3 space-y-2">
          <span className="label">Correct items (one point each by default)</span>
          {items.map((it, k) => (
            <div key={k} className="flex gap-2">
              <input className="input" value={it} onChange={(e) => upd(i, { answerKey: items.map((x, j) => (j === k ? e.target.value : x)), points: items.length })} />
              {items.length > 1 && <button className="text-slate-400 hover:text-red-600" onClick={() => upd(i, { answerKey: items.filter((_, j) => j !== k), points: items.length - 1 })} aria-label="Remove item">✕</button>}
            </div>
          ))}
          <button className="text-sm font-medium text-brand-700" onClick={() => upd(i, { answerKey: [...items, ''], points: items.length + 1 })}>+ Add item</button>
        </div>
      )}
      {q.qtype === 'essay' && (
        <div className="mt-3"><Field label="Grading rubric / key points (teacher only)"><textarea className="input" rows={2} value={typeof q.answerKey === 'string' ? q.answerKey : ''} onChange={(e) => upd(i, { answerKey: e.target.value })} /></Field></div>
      )}
    </div>
  );
}
