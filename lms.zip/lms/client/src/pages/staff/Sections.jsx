import { useState } from 'react';
import { api, fullName } from '../../api';
import { useAuth } from '../../auth';
import { Badge, Button, Empty, ErrorNote, Field, Modal, PageLoader, Table, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';

export default function Sections() {
  const { user } = useAuth();
  const isAdmin = user.role === 'admin';
  const toast = useToast();
  const { data, loading, error, reload } = useLoad(() => api.get('/admin/sections'));
  const [edit, setEdit] = useState(null); // {id?, name, description}
  const [view, setView] = useState(null); // section whose students are shown
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const save = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try {
      if (edit.id) await api.put(`/admin/sections/${edit.id}`, { name: edit.name, description: edit.description || '' });
      else await api.post('/admin/sections', { name: edit.name, description: edit.description || '' });
      toast(edit.id ? 'Section updated' : 'Section created'); setEdit(null); reload();
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  const remove = async (s) => {
    if (!window.confirm(`Delete section "${s.name}"?`)) return;
    try { await api.del(`/admin/sections/${s.id}`); toast('Section deleted'); reload(); } catch (ex) { toast(ex.message, 'error'); }
  };

  return (
    <>
      <PageHeader title="Sections" sub="Students are grouped automatically by the section they registered in">
        {isAdmin && <Button onClick={() => { setErr(''); setEdit({ name: '', description: '' }); }}>+ New section</Button>}
      </PageHeader>
      {loading ? <PageLoader /> : error ? <ErrorNote error={error} /> : data.length === 0 ? <Empty title="No sections yet">{isAdmin ? 'Create the first section so students can register.' : 'Ask an administrator to create sections.'}</Empty> : (
        <Table head={['Section', 'Description', 'Students', '']}>
          {data.map((s) => (
            <tr key={s.id}>
              <td className="td font-semibold">{s.name}</td>
              <td className="td text-slate-500">{s.description || '—'}</td>
              <td className="td"><Badge color="blue">{s.student_count}</Badge></td>
              <td className="td text-right"><div className="flex justify-end gap-2">
                <button className="btn-secondary btn-sm" onClick={() => setView(s)}>View students</button>
                {isAdmin && <button className="btn-secondary btn-sm" onClick={() => { setErr(''); setEdit(s); }}>Rename / Edit</button>}
                {isAdmin && <button className="btn-danger btn-sm" onClick={() => remove(s)}>Delete</button>}
              </div></td>
            </tr>
          ))}
        </Table>
      )}

      {edit && (
        <Modal title={edit.id ? 'Edit section' : 'New section'} onClose={() => setEdit(null)}>
          <form onSubmit={save} className="space-y-4">
            <Field label="Section name"><input className="input" required maxLength={80} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label="Description (optional)"><input className="input" maxLength={300} value={edit.description || ''} onChange={(e) => setEdit({ ...edit, description: e.target.value })} /></Field>
            <ErrorNote error={err} />
            <div className="flex justify-end gap-2"><Button variant="secondary" type="button" onClick={() => setEdit(null)}>Cancel</Button><Button type="submit" loading={busy}>Save</Button></div>
          </form>
        </Modal>
      )}
      {view && <SectionStudents section={view} onClose={() => setView(null)} />}
    </>
  );
}

function SectionStudents({ section, onClose }) {
  const { data, loading, error } = useLoad(() => api.get(`/admin/sections/${section.id}/students`), [section.id]);
  return (
    <Modal title={`Students in ${section.name}`} onClose={onClose} wide>
      {loading ? <PageLoader /> : error ? <ErrorNote error={error} /> : data.length === 0 ? <Empty title="No students in this section yet" /> : (
        <Table head={['Name', 'Gmail', 'Verified']}>
          {data.map((s) => (
            <tr key={s.id}><td className="td">{fullName(s)}</td><td className="td">{s.email}</td><td className="td">{s.email_verified ? <Badge color="green">Verified</Badge> : <Badge color="amber">Pending</Badge>}</td></tr>
          ))}
        </Table>
      )}
    </Modal>
  );
}
