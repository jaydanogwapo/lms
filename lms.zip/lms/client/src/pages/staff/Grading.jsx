import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api, fmtDate, fullName, qtypeLabel } from '../../api';
import { Badge, Button, Empty, ErrorNote, Modal, PageLoader, Table, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';

const show = (v) => (v == null || v === '' ? <em className="text-slate-400">No answer</em> : Array.isArray(v) ? v.join(', ') : String(v));

export default function Grading() {
  const { id } = useParams();
  const subs = useLoad(() => api.get(`/activities/${id}/submissions`), [id]);
  const [open, setOpen] = useState(null);

  return (
    <>
      <PageHeader title="Student submissions" sub="Objective answers are auto-graded. Essays and unmatched short answers need your review.">
        <Link className="btn-secondary" to="/staff/activities">← Back</Link>
      </PageHeader>
      {subs.loading ? <PageLoader /> : subs.error ? <ErrorNote error={subs.error} /> : subs.data.length === 0 ? <Empty title="No submissions or progress yet" /> : (
        <Table head={['Student', 'Section', 'Status', 'Submitted', 'Score', '']}>
          {subs.data.map((s) => (
            <tr key={s.id}>
              <td className="td"><div className="font-medium">{fullName(s)}</div><div className="text-xs text-slate-500">{s.email}</div></td>
              <td className="td">{s.section_name || '—'}</td>
              <td className="td">{s.status === 'submitted' ? (s.needs_review ? <Badge color="amber">Needs review</Badge> : <Badge color="green">Graded</Badge>) : <Badge color="gray">In progress</Badge>}</td>
              <td className="td text-slate-600">{fmtDate(s.submitted_at)}</td>
              <td className="td font-semibold">{s.status === 'submitted' ? `${Number(s.total_score)} / ${Number(s.max_score)}` : '—'}</td>
              <td className="td text-right">{s.status === 'submitted' && <button className="btn-primary btn-sm" onClick={() => setOpen(s.id)}>Check & grade</button>}</td>
            </tr>
          ))}
        </Table>
      )}
      {open && <GradeModal id={open} onClose={() => setOpen(null)} onSaved={() => { setOpen(null); subs.reload(); }} />}
    </>
  );
}

function GradeModal({ id, onClose, onSaved }) {
  const toast = useToast();
  const { data, loading, error } = useLoad(() => api.get(`/activities/submissions/${id}`), [id]);
  const [scores, setScores] = useState(null);
  const [fb, setFb] = useState(null);
  const [overall, setOverall] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  if (data && !scores) {
    setScores(Object.fromEntries(data.answers.map((a) => [a.questionId, a.score ?? 0])));
    setFb(Object.fromEntries(data.answers.map((a) => [a.questionId, a.feedback || ''])));
    setOverall(data.feedback || '');
  }

  const save = async () => {
    setBusy(true); setErr('');
    try {
      const answers = data.answers.map((a) => ({ questionId: a.questionId, score: Number(scores[a.questionId] || 0), feedback: fb[a.questionId] || '' }));
      await api.put(`/activities/submissions/${id}/grade`, { answers, feedback: overall });
      toast('Grade saved'); onSaved();
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  const total = scores ? Object.values(scores).reduce((a, b) => a + Number(b || 0), 0) : 0;

  return (
    <Modal title={data ? `${data.student.firstName} ${data.student.lastName}` : 'Submission'} onClose={onClose} wide>
      {loading || !scores ? (error ? <ErrorNote error={error} /> : <PageLoader />) : (
        <div className="space-y-4">
          {data.answers.map((a, i) => (
            <div key={a.questionId} className="rounded-lg border border-slate-200 p-4">
              <div className="mb-1 flex items-center gap-2 text-xs text-slate-500"><Badge color="blue">{qtypeLabel(a.qtype)}</Badge> Question {i + 1} · {a.points} pt(s)</div>
              <p className="font-medium">{a.prompt}</p>
              {a.choices && <p className="mt-1 text-xs text-slate-500">Choices: {a.choices.join(' | ')}</p>}
              <div className="mt-2 grid gap-2 text-sm sm:grid-cols-2">
                <div className="rounded bg-slate-50 p-2"><div className="text-xs font-semibold text-slate-500">Student answer</div>{show(a.response)}</div>
                <div className="rounded bg-emerald-50 p-2"><div className="text-xs font-semibold text-emerald-700">Answer key</div>{show(a.answerKey)}</div>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <label className="flex items-center gap-2 text-sm">Score
                  <input className="input w-24 py-1" type="number" min={0} max={a.points} step="0.5" value={scores[a.questionId]} onChange={(e) => setScores({ ...scores, [a.questionId]: e.target.value })} /> / {a.points}</label>
                <input className="input flex-1 py-1" placeholder="Feedback for this answer (optional)" value={fb[a.questionId]} onChange={(e) => setFb({ ...fb, [a.questionId]: e.target.value })} />
              </div>
            </div>
          ))}
          <div><label className="label">Overall feedback</label><textarea className="input" rows={2} value={overall} onChange={(e) => setOverall(e.target.value)} /></div>
          <ErrorNote error={err} />
          <div className="flex items-center justify-between">
            <div className="text-lg font-bold">Total: {total} / {data.maxScore}</div>
            <div className="flex gap-2"><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={save} loading={busy}>Save grade</Button></div>
          </div>
        </div>
      )}
    </Modal>
  );
}
