import { useMemo, useState } from 'react';
import { api, fullName } from '../../api';
import { useAuth } from '../../auth';
import { Badge, Empty, ErrorNote, PageLoader, Table, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';

export default function Students() {
  const { user } = useAuth();
  const isAdmin = user.role === 'admin';
  const toast = useToast();
  const students = useLoad(() => api.get('/admin/students'));
  const sections = useLoad(() => api.get('/admin/sections'));
  const [q, setQ] = useState('');
  const [sec, setSec] = useState('');

  const rows = useMemo(() => (students.data || []).filter((s) => {
    const hay = `${fullName(s)} ${s.email}`.toLowerCase();
    return hay.includes(q.toLowerCase()) && (!sec || String(s.section_id) === sec);
  }), [students.data, q, sec]);

  const move = async (s, sectionId) => {
    try { await api.put(`/admin/students/${s.id}/section`, { sectionId: Number(sectionId) }); toast(`${s.first_name} moved`); students.reload(); sections.reload(); }
    catch (ex) { toast(ex.message, 'error'); }
  };
  const toggle = async (s) => {
    try { await api.put(`/admin/students/${s.id}/active`, { active: !s.is_active }); students.reload(); } catch (ex) { toast(ex.message, 'error'); }
  };

  return (
    <>
      <PageHeader title="Students" sub={isAdmin ? 'Transfer students between sections or deactivate accounts' : 'All registered students'} />
      <div className="mb-4 flex flex-wrap gap-3">
        <input className="input max-w-xs" placeholder="Search name or email" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className="input max-w-[200px]" value={sec} onChange={(e) => setSec(e.target.value)}>
          <option value="">All sections</option>
          {(sections.data || []).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </div>
      {students.loading ? <PageLoader /> : students.error ? <ErrorNote error={students.error} /> : rows.length === 0 ? <Empty title="No students found" /> : (
        <Table head={['Name', 'Gmail', 'Status', 'Section', ...(isAdmin ? [''] : [])]}>
          {rows.map((s) => (
            <tr key={s.id} className={s.is_active ? '' : 'opacity-60'}>
              <td className="td font-medium">{fullName(s)}</td>
              <td className="td">{s.email}</td>
              <td className="td">{!s.is_active ? <Badge color="red">Deactivated</Badge> : s.email_verified ? <Badge color="green">Verified</Badge> : <Badge color="amber">Unverified</Badge>}</td>
              <td className="td">
                {isAdmin ? (
                  <select className="input py-1" value={s.section_id || ''} onChange={(e) => move(s, e.target.value)} aria-label={`Section for ${fullName(s)}`}>
                    {!s.section_id && <option value="">Unassigned</option>}
                    {(sections.data || []).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
                  </select>
                ) : (s.section_name || '—')}
              </td>
              {isAdmin && <td className="td text-right"><button className="btn-secondary btn-sm" onClick={() => toggle(s)}>{s.is_active ? 'Deactivate' : 'Reactivate'}</button></td>}
            </tr>
          ))}
        </Table>
      )}
    </>
  );
}
