import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, fmtDate } from '../../api';
import { Badge, Button, Empty, ErrorNote, LevelBadge, Modal, PageLoader, Table, download, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';
import { SectionPicker } from './Materials';

export default function Activities() {
  const toast = useToast();
  const acts = useLoad(() => api.get('/activities'));
  const sections = useLoad(() => api.get('/admin/sections'));
  const [pub, setPub] = useState(null);

  const remove = async (a) => {
    if (!window.confirm(`Delete "${a.title}" and ALL student submissions for it? This cannot be undone.`)) return;
    try { await api.del(`/activities/${a.id}`); toast('Activity deleted'); acts.reload(); } catch (ex) { toast(ex.message, 'error'); }
  };
  const release = async (a) => {
    try { await api.put(`/activities/${a.id}/release`, { release: !a.release_scores }); toast(a.release_scores ? 'Scores hidden from students' : 'Scores released to students'); acts.reload(); }
    catch (ex) { toast(ex.message, 'error'); }
  };
  const unpublish = async (a) => {
    if (!window.confirm('Unpublish from ALL sections? Students will no longer see it.')) return;
    try { await api.post(`/activities/${a.id}/unpublish`, {}); toast('Unpublished'); acts.reload(); } catch (ex) { toast(ex.message, 'error'); }
  };

  return (
    <>
      <PageHeader title="Activities & quizzes" sub="Create quizzes from the Materials page using AI">
        <Link className="btn-primary" to="/staff/materials">✨ New quiz from material</Link>
      </PageHeader>
      {acts.loading ? <PageLoader /> : acts.error ? <ErrorNote error={acts.error} /> : acts.data.length === 0 ? (
        <Empty title="No activities yet">Upload a material, then use “Generate quiz”.</Empty>
      ) : (
        <Table head={['Activity', 'Level', 'Sections', 'Deadline', 'Submissions', '']}>
          {acts.data.map((a) => (
            <tr key={a.id}>
              <td className="td"><div className="font-semibold">{a.title}</div>
                <div className="text-xs text-slate-500">{a.question_count} questions · {a.is_published ? <span className="text-emerald-600">Published</span> : <span className="text-amber-600">Draft</span>}</div></td>
              <td className="td"><LevelBadge level={a.level} /></td>
              <td className="td"><div className="flex max-w-[200px] flex-wrap gap-1">{a.sections.length ? a.sections.map((s) => <Badge key={s.id} color="blue">{s.name}</Badge>) : <span className="text-xs text-slate-400">—</span>}</div></td>
              <td className="td text-slate-600">{fmtDate(a.deadline)}</td>
              <td className="td">{a.submitted_count}{a.review_count > 0 && <Badge color="amber"> {a.review_count} to review</Badge>}</td>
              <td className="td"><div className="flex flex-wrap justify-end gap-2">
                <Link className="btn-primary btn-sm" to={`/staff/activities/${a.id}/grading`}>Submissions</Link>
                <Link className="btn-secondary btn-sm" to={`/staff/activities/${a.id}/edit`}>Edit</Link>
                <button className="btn-secondary btn-sm" onClick={() => setPub(a)}>Assign sections</button>
                <button className="btn-secondary btn-sm" onClick={() => release(a)}>{a.release_scores ? 'Hide scores' : 'Release scores'}</button>
                {a.is_published && <button className="btn-secondary btn-sm" onClick={() => unpublish(a)}>Unpublish</button>}
                <button className="btn-secondary btn-sm" onClick={() => download(`/reports/export/activity/${a.id}.xlsx`)}>Excel</button>
                <button className="btn-secondary btn-sm" onClick={() => download(`/reports/export/activity/${a.id}.pdf`)}>PDF</button>
                <button className="btn-danger btn-sm" onClick={() => remove(a)}>Delete</button>
              </div></td>
            </tr>
          ))}
        </Table>
      )}
      {pub && <AssignModal activity={pub} sections={sections.data || []} onClose={() => setPub(null)} onDone={() => { setPub(null); acts.reload(); }} />}
    </>
  );
}

function AssignModal({ activity, sections, onClose, onDone }) {
  const toast = useToast();
  const [sel, setSel] = useState(activity.sections.map((s) => s.id));
  const [notify, setNotify] = useState(true);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const already = activity.sections.map((s) => s.id);
  const go = async () => {
    setErr(''); setBusy(true);
    try {
      const r = await api.post(`/activities/${activity.id}/publish`, { sectionIds: sel, notify });
      toast(r.published ? `Published to ${r.published} new section(s)` : 'No new sections were added'); onDone();
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  return (
    <Modal title={`Assign "${activity.title}"`} onClose={onClose}>
      <p className="mb-3 text-sm text-slate-600">Add more sections. Students in them receive the identical stored questionnaire. Use “Unpublish” to remove access.</p>
      <SectionPicker sections={sections} selected={sel} onChange={(v) => setSel([...new Set([...already, ...v])])} />
      <label className="mt-4 flex items-center gap-2 text-sm"><input type="checkbox" checked={notify} onChange={(e) => setNotify(e.target.checked)} /> Email students in newly added sections</label>
      <div className="mt-3"><ErrorNote error={err} /></div>
      <div className="mt-4 flex justify-end gap-2"><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={go} loading={busy} disabled={!sel.length}>Publish</Button></div>
    </Modal>
  );
}
