import { useState } from 'react';
import { api } from '../../api';
import { Badge, Button, ErrorNote, Field, Modal, PageLoader, Table, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';

export default function Teachers() {
  const toast = useToast();
  const { data, loading, error, reload } = useLoad(() => api.get('/admin/teachers'));
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ firstName: '', lastName: '', email: '', password: '', role: 'teacher' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [pw, setPw] = useState(null);

  const create = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await api.post('/admin/teachers', f); toast('Account created'); setOpen(false); setF({ firstName: '', lastName: '', email: '', password: '', role: 'teacher' }); reload(); }
    catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  const toggle = async (t) => {
    try { await api.put(`/admin/teachers/${t.id}/active`, { active: !t.is_active }); reload(); } catch (ex) { toast(ex.message, 'error'); }
  };
  const resetPw = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true);
    try { await api.put(`/admin/teachers/${pw.id}/password`, { password: pw.value }); toast('Password updated'); setPw(null); }
    catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader title="Staff accounts" sub="Only administrators can create and manage teacher accounts">
        <Button onClick={() => { setErr(''); setOpen(true); }}>+ New account</Button>
      </PageHeader>
      {loading ? <PageLoader /> : error ? <ErrorNote error={error} /> : (
        <Table head={['Name', 'Email', 'Role', 'Status', '']}>
          {data.map((t) => (
            <tr key={t.id}>
              <td className="td font-medium">{t.first_name} {t.last_name}</td><td className="td">{t.email}</td>
              <td className="td"><Badge color={t.role === 'admin' ? 'indigo' : 'blue'}>{t.role}</Badge></td>
              <td className="td">{t.is_active ? <Badge color="green">Active</Badge> : <Badge color="red">Deactivated</Badge>}</td>
              <td className="td text-right"><div className="flex justify-end gap-2">
                <button className="btn-secondary btn-sm" onClick={() => { setErr(''); setPw({ id: t.id, value: '' }); }}>Reset password</button>
                <button className="btn-secondary btn-sm" onClick={() => toggle(t)}>{t.is_active ? 'Deactivate' : 'Reactivate'}</button>
              </div></td>
            </tr>
          ))}
        </Table>
      )}
      {open && (
        <Modal title="New staff account" onClose={() => setOpen(false)}>
          <form onSubmit={create} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <Field label="First name"><input className="input" required value={f.firstName} onChange={(e) => setF({ ...f, firstName: e.target.value })} /></Field>
              <Field label="Last name"><input className="input" required value={f.lastName} onChange={(e) => setF({ ...f, lastName: e.target.value })} /></Field>
            </div>
            <Field label="Email"><input className="input" type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
            <Field label="Temporary password" hint="At least 8 characters"><input className="input" type="password" required minLength={8} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>
            <Field label="Role"><select className="input" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}><option value="teacher">Teacher</option><option value="admin">Administrator</option></select></Field>
            <ErrorNote error={err} />
            <div className="flex justify-end gap-2"><Button variant="secondary" type="button" onClick={() => setOpen(false)}>Cancel</Button><Button type="submit" loading={busy}>Create</Button></div>
          </form>
        </Modal>
      )}
      {pw && (
        <Modal title="Reset password" onClose={() => setPw(null)}>
          <form onSubmit={resetPw} className="space-y-3">
            <Field label="New password"><input className="input" type="password" required minLength={8} value={pw.value} onChange={(e) => setPw({ ...pw, value: e.target.value })} /></Field>
            <ErrorNote error={err} />
            <div className="flex justify-end gap-2"><Button variant="secondary" type="button" onClick={() => setPw(null)}>Cancel</Button><Button type="submit" loading={busy}>Update</Button></div>
          </form>
        </Modal>
      )}
    </>
  );
}
