import { useAuth } from '../../auth';
import Shell from '../../components/Shell';

export default function StaffLayout() {
  const { user } = useAuth();
  const nav = [
    { to: '/staff', label: 'Dashboard', icon: '📊', end: true },
    { to: '/staff/sections', label: 'Sections', icon: '🏫' },
    { to: '/staff/students', label: 'Students', icon: '🧑‍🎓' },
    { to: '/staff/materials', label: 'Materials & AI', icon: '📄' },
    { to: '/staff/activities', label: 'Activities', icon: '📝' },
    ...(user.role === 'admin' ? [{ to: '/staff/teachers', label: 'Staff Accounts', icon: '🔑' }] : []),
  ];
  return <Shell nav={nav} title="LMS Admin" subtitle={user.role === 'admin' ? 'Administrator' : 'Teacher'} />;
}
