import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api, LEVELS, cap, fmtDay } from '../../api';
import { Badge, Button, Empty, ErrorNote, Field, LevelBadge, Modal, PageLoader, Table, download, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';

const size = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);

export default function Materials() {
  const toast = useToast();
  const mats = useLoad(() => api.get('/materials'));
  const sections = useLoad(() => api.get('/admin/sections'));
  const courses = useLoad(() => api.get('/admin/courses'));
  const [up, setUp] = useState(false);
  const [pub, setPub] = useState(null);
  const [ed, setEd] = useState(null);

  const remove = async (m) => {
    if (!window.confirm(`Delete "${m.title}"? Quizzes already created from it are kept.`)) return;
    try { await api.del(`/materials/${m.id}`); toast('Material deleted'); mats.reload(); } catch (ex) { toast(ex.message, 'error'); }
  };
  const unpublish = async (m, s) => {
    try { await api.post(`/materials/${m.id}/unpublish`, { sectionId: s.id }); toast(`Removed from ${s.name}`); mats.reload(); } catch (ex) { toast(ex.message, 'error'); }
  };

  return (
    <>
      <PageHeader title="Learning materials" sub="Upload files, publish them as lessons, or generate quizzes with AI">
        <Button onClick={() => setUp(true)}>⬆ Upload material</Button>
      </PageHeader>
      {mats.loading ? <PageLoader /> : mats.error ? <ErrorNote error={mats.error} /> : mats.data.length === 0 ? (
        <Empty title="No materials yet">Upload a PDF, Word, PowerPoint or text file to begin.</Empty>
      ) : (
        <Table head={['Material', 'Level', 'Course', 'Published to', 'Uploaded', '']}>
          {mats.data.map((m) => (
            <tr key={m.id}>
              <td className="td"><div className="font-semibold">{m.title}</div><div className="text-xs text-slate-500">{m.original_name} · {size(m.size_bytes)}</div></td>
              <td className="td"><LevelBadge level={m.level} /></td>
              <td className="td">{m.course_title || '—'}</td>
              <td className="td">
                <div className="flex max-w-[220px] flex-wrap gap-1">
                  {m.sections.length === 0 ? <span className="text-xs text-slate-400">Not published</span> : m.sections.map((s) => (
                    <span key={s.id} className="inline-flex items-center gap-1 rounded-full bg-blue-100 px-2 py-0.5 text-xs font-semibold text-blue-700">{s.name}
                      <button title="Unpublish from this section" onClick={() => unpublish(m, s)} className="text-blue-400 hover:text-red-600">×</button></span>
                  ))}
                </div>
              </td>
              <td className="td text-slate-500">{fmtDay(m.created_at)}</td>
              <td className="td"><div className="flex flex-wrap justify-end gap-2">
                <button className="btn-primary btn-sm" onClick={() => setPub(m)}>Publish lesson</button>
                {m.has_text ? <Link className="btn-secondary btn-sm" to={`/staff/generate/${m.id}`}>✨ Generate quiz</Link> : <Badge color="amber">No text found</Badge>}
                <button className="btn-secondary btn-sm" onClick={() => download(`/materials/${m.id}/download`)}>Download</button>
                <button className="btn-secondary btn-sm" onClick={() => setEd(m)}>Edit</button>
                <button className="btn-danger btn-sm" onClick={() => remove(m)}>Delete</button>
              </div></td>
            </tr>
          ))}
        </Table>
      )}
      {up && <UploadModal courses={courses} onClose={() => setUp(false)} onDone={() => { setUp(false); mats.reload(); }} />}
      {pub && <PublishModal material={pub} sections={sections.data || []} onClose={() => setPub(null)} onDone={() => { setPub(null); mats.reload(); }} />}
      {ed && <EditModal material={ed} courses={courses.data || []} onClose={() => setEd(null)} onDone={() => { setEd(null); mats.reload(); }} />}
    </>
  );
}

function CourseSelect({ courses, value, onChange }) {
  const toast = useToast();
  const add = async () => {
    const title = window.prompt('New course name');
    if (!title || !title.trim()) return;
    try { const c = await api.post('/admin/courses', { title }); await courses.reload?.(); onChange(String(c.id)); } catch (ex) { toast(ex.message, 'error'); }
  };
  return (
    <div className="flex gap-2">
      <select className="input" value={value} onChange={(e) => onChange(e.target.value)}>
        <option value="">No course</option>
        {(courses.data || courses).map?.((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
      </select>
      {courses.reload && <button type="button" className="btn-secondary whitespace-nowrap" onClick={add}>+ Course</button>}
    </div>
  );
}

function UploadModal({ courses, onClose, onDone }) {
  const toast = useToast();
  const [f, setF] = useState({ title: '', description: '', level: 'beginner', courseId: '' });
  const [file, setFile] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    if (!file) return setErr('Choose a file first');
    const fd = new FormData();
    fd.append('title', f.title); fd.append('description', f.description); fd.append('level', f.level);
    if (f.courseId) fd.append('courseId', f.courseId);
    fd.append('file', file);
    setBusy(true);
    try { const r = await api.upload('/materials', fd); toast(`Uploaded. ${r.extractedChars.toLocaleString()} characters extracted.`); onDone(); }
    catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  return (
    <Modal title="Upload learning material" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <Field label="File" hint="PDF, DOC/DOCX, PPT/PPTX, TXT, MD, CSV, RTF or HTML"><input className="input" type="file" required accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.md,.csv,.rtf,.html,.htm"
          onChange={(e) => { const x = e.target.files[0]; setFile(x); if (x && !f.title) setF({ ...f, title: x.name.replace(/\.[^.]+$/, '') }); }} /></Field>
        <Field label="Title"><input className="input" required maxLength={160} value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
        <Field label="Description"><textarea className="input" rows={2} maxLength={1000} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Level"><select className="input" value={f.level} onChange={(e) => setF({ ...f, level: e.target.value })}>{LEVELS.map((l) => <option key={l} value={l}>{cap(l)}</option>)}</select></Field>
          <Field label="Course"><CourseSelect courses={courses} value={f.courseId} onChange={(v) => setF({ ...f, courseId: v })} /></Field>
        </div>
        <ErrorNote error={err} />
        <div className="flex justify-end gap-2"><Button variant="secondary" type="button" onClick={onClose}>Cancel</Button><Button type="submit" loading={busy}>{busy ? 'Analyzing…' : 'Upload & analyze'}</Button></div>
      </form>
    </Modal>
  );
}

function EditModal({ material, courses, onClose, onDone }) {
  const [f, setF] = useState({ title: material.title, description: material.description || '', level: material.level, courseId: material.course_id ? String(material.course_id) : '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setBusy(true); setErr('');
    try { await api.put(`/materials/${material.id}`, { ...f, courseId: f.courseId ? Number(f.courseId) : null }); onDone(); }
    catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  return (
    <Modal title="Edit material" onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <Field label="Title"><input className="input" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></Field>
        <Field label="Description"><textarea className="input" rows={2} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Level"><select className="input" value={f.level} onChange={(e) => setF({ ...f, level: e.target.value })}>{LEVELS.map((l) => <option key={l} value={l}>{cap(l)}</option>)}</select></Field>
          <Field label="Course"><CourseSelect courses={courses} value={f.courseId} onChange={(v) => setF({ ...f, courseId: v })} /></Field>
        </div>
        <ErrorNote error={err} />
        <div className="flex justify-end gap-2"><Button variant="secondary" type="button" onClick={onClose}>Cancel</Button><Button type="submit" loading={busy}>Save</Button></div>
      </form>
    </Modal>
  );
}

export function SectionPicker({ sections, selected, onChange }) {
  const toggle = (id) => onChange(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id]);
  if (!sections.length) return <p className="text-sm text-slate-500">No sections exist yet. An administrator must create one first.</p>;
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {sections.map((s) => (
        <label key={s.id} className={`flex cursor-pointer items-center gap-2 rounded-lg border px-3 py-2 text-sm ${selected.includes(s.id) ? 'border-brand-500 bg-brand-50' : 'border-slate-200'}`}>
          <input type="checkbox" checked={selected.includes(s.id)} onChange={() => toggle(s.id)} />
          <span className="font-medium">{s.name}</span><span className="ml-auto text-xs text-slate-500">{s.student_count} students</span>
        </label>
      ))}
    </div>
  );
}

function PublishModal({ material, sections, onClose, onDone }) {
  const toast = useToast();
  const [sel, setSel] = useState([]);
  const [notify, setNotify] = useState(true);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const go = async () => {
    setErr(''); setBusy(true);
    try {
      const r = await api.post(`/materials/${material.id}/publish`, { sectionIds: sel, notify });
      toast(r.published ? `Lesson published to ${r.published} section(s)${notify ? '. Emails are being sent.' : ''}` : 'Already published to those sections');
      onDone();
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  return (
    <Modal title={`Publish "${material.title}"`} onClose={onClose}>
      <p className="mb-3 text-sm text-slate-600">Students only see this lesson if they belong to a selected section.</p>
      <SectionPicker sections={sections} selected={sel} onChange={setSel} />
      <label className="mt-4 flex items-center gap-2 text-sm"><input type="checkbox" checked={notify} onChange={(e) => setNotify(e.target.checked)} /> Email students in these sections</label>
      <div className="mt-3"><ErrorNote error={err} /></div>
      <div className="mt-4 flex justify-end gap-2"><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={go} loading={busy} disabled={!sel.length}>Publish</Button></div>
    </Modal>
  );
}
