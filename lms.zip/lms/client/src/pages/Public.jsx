import { useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../auth';
import { api } from '../api';
import { Button, ErrorNote, Field, PageLoader, useLoad } from '../ui';

function AuthFrame({ title, subtitle, children, footer }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-brand-900 via-brand-800 to-brand-600 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-7 shadow-2xl">
        <Link to="/" className="mb-5 flex items-center gap-2 text-sm font-semibold text-brand-700">🎓 AI Learning Management System</Link>
        <h1 className="text-2xl font-bold">{title}</h1>
        <p className="mb-5 text-sm text-slate-500">{subtitle}</p>
        {children}
        {footer && <div className="mt-5 border-t border-slate-100 pt-4 text-center text-sm text-slate-500">{footer}</div>}
      </div>
    </div>
  );
}

export function Landing() {
  const { user, loading } = useAuth();
  if (loading) return <PageLoader />;
  if (user) return <Navigate to={user.role === 'student' ? '/student' : '/staff'} replace />;
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-brand-900 via-brand-800 to-brand-600 p-6 text-white">
      <div className="mb-3 text-6xl">🎓</div>
      <h1 className="text-center text-3xl font-bold text-white sm:text-4xl">AI Learning Management System</h1>
      <p className="mt-2 max-w-xl text-center text-blue-100">Upload lessons, generate quizzes with AI, and deliver identical activities to every student in a section.</p>
      <div className="mt-8 grid w-full max-w-2xl gap-4 sm:grid-cols-2">
        <Link to="/student-login" className="rounded-2xl bg-white p-6 text-slate-800 shadow-lg transition hover:-translate-y-0.5">
          <div className="text-3xl">🧑‍🎓</div><div className="mt-2 text-lg font-bold">I'm a Student</div>
          <div className="text-sm text-slate-500">Log in to your lessons and activities</div>
        </Link>
        <Link to="/staff-login" className="rounded-2xl bg-white p-6 text-slate-800 shadow-lg transition hover:-translate-y-0.5">
          <div className="text-3xl">👩‍🏫</div><div className="mt-2 text-lg font-bold">Teacher / Admin</div>
          <div className="text-sm text-slate-500">Manage classes, materials and grading</div>
        </Link>
      </div>
      <Link to="/register" className="mt-6 text-sm text-blue-100 underline">New student? Create an account</Link>
    </div>
  );
}

function LoginForm({ kind }) {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [f, setF] = useState({ email: '', password: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [unverified, setUnverified] = useState(false);
  const [info, setInfo] = useState('');

  const submit = async (e) => {
    e.preventDefault(); setErr(''); setInfo(''); setBusy(true); setUnverified(false);
    try {
      const u = await login(kind, f.email, f.password);
      navigate(u.role === 'student' ? '/student' : '/staff');
    } catch (ex) {
      setErr(ex.message);
      setUnverified(kind === 'student' && /verify/i.test(ex.message));
    } finally { setBusy(false); }
  };

  const resend = async () => {
    try { const r = await api.post('/auth/resend-verification', { email: f.email }); setInfo(r.message); } catch (ex) { setErr(ex.message); }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <Field label="Email"><input className="input" type="email" required autoComplete="username" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
      <Field label="Password"><input className="input" type="password" required autoComplete="current-password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></Field>
      <ErrorNote error={err} />
      {info && <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{info}</div>}
      {unverified && <button type="button" onClick={resend} className="text-sm font-medium text-brand-700 underline">Resend verification email</button>}
      <Button type="submit" loading={busy} className="w-full">Log in</Button>
    </form>
  );
}

export const StudentLogin = () => (
  <AuthFrame title="Student login" subtitle="Welcome back! Log in with your Gmail account."
    footer={<>No account yet? <Link className="font-semibold text-brand-700" to="/register">Register</Link></>}>
    <LoginForm kind="student" />
  </AuthFrame>
);

export const StaffLogin = () => (
  <AuthFrame title="Teacher / Admin login" subtitle="Authorized staff only."
    footer={<Link className="text-brand-700" to="/student-login">Looking for the student login?</Link>}>
    <LoginForm kind="staff" />
  </AuthFrame>
);

export function Register() {
  const sections = useLoad(() => api.get('/auth/sections'));
  const [f, setF] = useState({ firstName: '', middleName: '', lastName: '', email: '', password: '', confirm: '', sectionId: '' });
  const [err, setErr] = useState('');
  const [done, setDone] = useState(null);
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    if (f.password !== f.confirm) return setErr('Passwords do not match');
    if (!/@gmail\.com$/i.test(f.email.trim())) return setErr('Please use an active Gmail address ending in @gmail.com');
    setBusy(true);
    try {
      const r = await api.post('/auth/register', { ...f, sectionId: Number(f.sectionId) });
      setDone(r);
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  if (done) {
    return (
      <AuthFrame title="Check your Gmail" subtitle={done.message} footer={<Link className="font-semibold text-brand-700" to="/student-login">Go to login</Link>}>
        <div className="rounded-lg bg-brand-50 p-4 text-sm text-brand-800">You must click the verification link before you can log in. The link expires in 24 hours.</div>
      </AuthFrame>
    );
  }

  return (
    <AuthFrame title="Student registration" subtitle="Use your real name and your correct section."
      footer={<>Already registered? <Link className="font-semibold text-brand-700" to="/student-login">Log in</Link></>}>
      <form onSubmit={submit} className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="First name"><input className="input" required value={f.firstName} onChange={set('firstName')} /></Field>
          <Field label="Middle name"><input className="input" value={f.middleName} onChange={set('middleName')} /></Field>
          <Field label="Last name"><input className="input" required value={f.lastName} onChange={set('lastName')} /></Field>
        </div>
        <Field label="Gmail address" hint="We'll send a verification link and your class notifications here."><input className="input" type="email" required placeholder="name@gmail.com" value={f.email} onChange={set('email')} /></Field>
        <Field label="Section">
          <select className="input" required value={f.sectionId} onChange={set('sectionId')}>
            <option value="">{sections.loading ? 'Loading…' : 'Select your section'}</option>
            {(sections.data || []).map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
        </Field>
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Password" hint="At least 8 characters"><input className="input" type="password" required minLength={8} autoComplete="new-password" value={f.password} onChange={set('password')} /></Field>
          <Field label="Confirm password"><input className="input" type="password" required autoComplete="new-password" value={f.confirm} onChange={set('confirm')} /></Field>
        </div>
        <ErrorNote error={err || sections.error} />
        <Button type="submit" loading={busy} className="w-full">Create account</Button>
      </form>
    </AuthFrame>
  );
}

export function VerifyEmail() {
  const [params] = useSearchParams();
  const token = params.get('token');
  const { loading, error, data } = useLoad(() => (token ? api.post('/auth/verify-email', { token }) : Promise.reject(new Error('Missing verification token'))), [token]);
  return (
    <AuthFrame title="Email verification" subtitle={loading ? 'Verifying your Gmail address…' : ''}>
      {loading ? <PageLoader /> : error ? <ErrorNote error={error} /> : (
        <div className="space-y-4">
          <div className="rounded-lg bg-emerald-50 p-4 text-emerald-800">✅ {data.message}</div>
          <Link to="/student-login" className="btn-primary w-full">Go to login</Link>
        </div>
      )}
    </AuthFrame>
  );
}
