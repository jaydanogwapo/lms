import { useAuth } from '../../auth';
import Shell from '../../components/Shell';

export default function StudentLayout() {
  const { user } = useAuth();
  const nav = [
    { to: '/student', label: 'My Profile', icon: '🏠', end: true },
    { to: '/student/lessons', label: 'My Lessons', icon: '📚' },
    { to: '/student/activities', label: 'Activities', icon: '📝' },
  ];
  return <Shell nav={nav} title="My Classroom" subtitle={user.sectionName || 'Student'} />;
}
