import { Link } from 'react-router-dom';
import { api, fmtDate } from '../../api';
import { Empty, ErrorNote, LevelBadge, PageLoader, StatusBadge, useLoad } from '../../ui';
import { PageHeader } from '../../components/Shell';

export default function MyActivities() {
  const { data, loading, error } = useLoad(() => api.get('/student/activities'));
  return (
    <>
      <PageHeader title="Activities & assessments" sub="Everyone in your section answers the same questionnaire" />
      {loading ? <PageLoader /> : error ? <ErrorNote error={error} /> : data.length === 0 ? <Empty title="Nothing assigned yet">New activities will show up here.</Empty> : (
        <div className="grid gap-4 md:grid-cols-2">
          {data.map((a) => {
            const late = a.deadline && new Date(a.deadline) < new Date() && a.status !== 'submitted';
            return (
              <div key={a.id} className="card flex flex-col">
                <div className="mb-2 flex flex-wrap items-center gap-2"><LevelBadge level={a.level} /><StatusBadge status={a.status} />{late && <span className="text-xs font-semibold text-red-600">Deadline passed</span>}</div>
                <h3 className="font-bold">{a.title}</h3>
                <p className="mt-1 line-clamp-3 flex-1 text-sm text-slate-600">{a.instructions || 'No instructions.'}</p>
                <div className="mt-3 text-xs text-slate-500">{a.question_count} questions · Due: {fmtDate(a.deadline)}</div>
                {a.total_score != null && <div className="mt-2 text-sm font-semibold text-emerald-700">Score: {a.total_score} / {a.max_score}</div>}
                <Link to={`/student/activities/${a.id}`} className="btn-primary mt-4">
                  {a.status === 'submitted' ? 'View' : a.status === 'in_progress' ? 'Continue' : late ? 'View' : 'Start'}
                </Link>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
