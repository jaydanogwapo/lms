import { Link } from 'react-router-dom';
import { api } from '../../api';
import { useAuth } from '../../auth';
import { Badge, ErrorNote, PageLoader, StatCard, useLoad } from '../../ui';
import { PageHeader } from '../../components/Shell';

export default function StudentHome() {
  const { user } = useAuth();
  const { data, loading, error } = useLoad(() => api.get('/student/summary'));
  const fullName = [user.firstName, user.middleName, user.lastName].filter(Boolean).join(' ');
  return (
    <>
      <PageHeader title={`Hello, ${user.firstName}!`} sub="Here's what's happening in your class" />
      <div className="card mb-6 flex flex-wrap items-center gap-5">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-brand-100 text-2xl font-bold text-brand-800">{user.firstName[0]}</div>
        <dl className="grid flex-1 gap-x-8 gap-y-2 text-sm sm:grid-cols-2">
          <div><dt className="text-xs uppercase text-slate-500">Full name</dt><dd className="font-semibold">{fullName}</dd></div>
          <div><dt className="text-xs uppercase text-slate-500">Section</dt><dd className="font-semibold">{user.sectionName || 'Unassigned'}</dd></div>
          <div><dt className="text-xs uppercase text-slate-500">Gmail</dt><dd className="font-semibold">{user.email} {user.emailVerified && <Badge color="green">Verified</Badge>}</dd></div>
          <div><dt className="text-xs uppercase text-slate-500">Role</dt><dd className="font-semibold">Student</dd></div>
        </dl>
      </div>
      {loading ? <PageLoader /> : error ? <ErrorNote error={error} /> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Link to="/student/lessons"><StatCard icon="📚" label="Lessons available" value={data.lessons} /></Link>
          <Link to="/student/activities"><StatCard icon="📝" label="Activities assigned" value={data.activities} /></Link>
          <StatCard icon="✅" label="Submitted" value={data.submitted} />
          <StatCard icon="⏰" label="Due within 3 days" value={data.due_soon} />
        </div>
      )}
    </>
  );
}
