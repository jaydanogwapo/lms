import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api, fmtDate, qtypeLabel } from '../../api';
import { Badge, Button, ErrorNote, LevelBadge, PageLoader, StatusBadge, useLoad, useToast } from '../../ui';
import { PageHeader } from '../../components/Shell';

export default function TakeActivity() {
  const { id } = useParams();
  const navigate = useNavigate();
  const toast = useToast();
  const { data, loading, error } = useLoad(() => api.get(`/student/activities/${id}`), [id]);
  const [answers, setAnswers] = useState({});
  const [dirty, setDirty] = useState(false);
  const [savedAt, setSavedAt] = useState(null);
  const [busy, setBusy] = useState('');
  const [err, setErr] = useState('');
  const init = useRef(false);

  useEffect(() => { if (data && !init.current) { init.current = true; setAnswers(data.responses || {}); } }, [data]);

  const readOnly = data && (data.status === 'submitted' || data.pastDeadline);
  const set = (qid, v) => { setAnswers((a) => ({ ...a, [qid]: v })); setDirty(true); };

  const save = async (quiet) => {
    setBusy('save'); setErr('');
    try { await api.put(`/student/activities/${id}/progress`, { answers }); setDirty(false); setSavedAt(new Date()); if (!quiet) toast('Progress saved'); }
    catch (e) { setErr(e.message); } finally { setBusy(''); }
  };

  // Auto-save every 30 s while there are unsaved changes.
  useEffect(() => {
    if (!dirty || readOnly) return undefined;
    const t = setTimeout(() => save(true), 30000);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [answers, dirty, readOnly]);

  const submit = async () => {
    const unanswered = data.questions.filter((q) => { const v = answers[q.id]; return v == null || v === '' || (Array.isArray(v) && !v.length); }).length;
    const msg = unanswered ? `You left ${unanswered} question(s) unanswered. Submit anyway? You can't change answers after submitting.` : 'Submit your answers? You can\'t change them afterwards.';
    if (!window.confirm(msg)) return;
    setBusy('submit'); setErr('');
    try { await api.post(`/student/activities/${id}/submit`, { answers }); toast('Submitted!'); navigate('/student/activities'); }
    catch (e) { setErr(e.message); } finally { setBusy(''); }
  };

  if (loading) return <PageLoader />;
  if (error) return <><ErrorNote error={error} /><Link className="btn-secondary mt-4" to="/student/activities">← Back</Link></>;
  const r = data.result;

  return (
    <>
      <PageHeader title={data.title}>
        <Link className="btn-secondary" to="/student/activities">← Back</Link>
      </PageHeader>
      <div className="card mb-5">
        <div className="mb-2 flex flex-wrap items-center gap-2"><LevelBadge level={data.level} /><StatusBadge status={data.status} /><span className="text-sm text-slate-500">Deadline: {fmtDate(data.deadline)}</span></div>
        <p className="whitespace-pre-wrap text-sm text-slate-700">{data.instructions || 'Answer all questions.'}</p>
        {data.pastDeadline && data.status !== 'submitted' && <div className="mt-3"><ErrorNote error="The deadline has passed, so this activity is now read-only." /></div>}
        {r && (
          <div className="mt-4 rounded-lg bg-emerald-50 p-3 text-sm text-emerald-900">
            <div className="text-base font-bold">Score: {r.totalScore} / {r.maxScore}{!r.graded && <span className="ml-2 font-normal text-amber-700">(some answers are still being reviewed)</span>}</div>
            {r.feedback && <div className="mt-1">Teacher feedback: {r.feedback}</div>}
          </div>
        )}
        {data.status === 'submitted' && !r && <div className="mt-3 rounded-lg bg-blue-50 p-3 text-sm text-blue-800">Submitted. Your score will appear here when your teacher releases it.</div>}
      </div>

      <div className="space-y-4">
        {data.questions.map((q, i) => {
          const pq = r?.perQuestion?.[q.id];
          return (
            <div key={q.id} className="card">
              <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-100 font-bold text-brand-800">{i + 1}</span>
                <Badge color="blue">{qtypeLabel(q.qtype)}</Badge><span>{q.points} pt(s)</span>
                {pq && pq.score != null && <span className="ml-auto font-semibold text-emerald-700">{pq.score} / {q.points}</span>}
              </div>
              <p className="mb-3 font-medium">{q.prompt}</p>
              <Answer q={q} value={answers[q.id]} onChange={(v) => set(q.id, v)} disabled={readOnly} />
              {pq && (
                <div className="mt-3 space-y-1 rounded-lg bg-slate-50 p-3 text-sm">
                  {pq.correctAnswer != null && pq.correctAnswer !== '' && <div><span className="font-semibold text-emerald-700">Correct answer:</span> {Array.isArray(pq.correctAnswer) ? pq.correctAnswer.join(', ') : String(pq.correctAnswer)}</div>}
                  {pq.feedback && <div><span className="font-semibold">Feedback:</span> {pq.feedback}</div>}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {!readOnly && (
        <div className="sticky bottom-0 -mx-4 mt-6 border-t border-slate-200 bg-white/95 p-4 backdrop-blur sm:-mx-6">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3">
            <span className="text-sm text-slate-500">{savedAt ? `Saved ${savedAt.toLocaleTimeString()}` : dirty ? 'Unsaved changes' : 'Autosaves every 30 seconds'}</span>
            <div className="flex gap-2"><Button variant="secondary" onClick={() => save(false)} loading={busy === 'save'}>Save progress</Button><Button onClick={submit} loading={busy === 'submit'}>Submit</Button></div>
          </div>
          {err && <div className="mx-auto mt-2 max-w-6xl"><ErrorNote error={err} /></div>}
        </div>
      )}
    </>
  );
}

function Answer({ q, value, onChange, disabled }) {
  if (q.qtype === 'multiple_choice') {
    return (
      <div className="space-y-2">
        {q.choices.map((c) => (
          <label key={c} className={`flex cursor-pointer items-center gap-3 rounded-lg border px-3 py-2 text-sm ${value === c ? 'border-brand-500 bg-brand-50' : 'border-slate-200'}`}>
            <input type="radio" name={`q${q.id}`} disabled={disabled} checked={value === c} onChange={() => onChange(c)} />{c}
          </label>
        ))}
      </div>
    );
  }
  if (q.qtype === 'true_false') {
    return (
      <div className="flex gap-3">
        {['True', 'False'].map((v) => (
          <label key={v} className={`flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium ${value === v ? 'border-brand-500 bg-brand-50' : 'border-slate-200'}`}>
            <input type="radio" name={`q${q.id}`} disabled={disabled} checked={value === v} onChange={() => onChange(v)} />{v}
          </label>
        ))}
      </div>
    );
  }
  if (q.qtype === 'enumeration') {
    return <textarea className="input" rows={4} disabled={disabled} placeholder="Type one item per line" value={Array.isArray(value) ? value.join('\n') : (value || '')} onChange={(e) => onChange(e.target.value.split('\n'))} />;
  }
  if (q.qtype === 'essay') return <textarea className="input" rows={7} disabled={disabled} placeholder="Write your answer…" value={value || ''} onChange={(e) => onChange(e.target.value)} />;
  if (q.qtype === 'short_answer') return <textarea className="input" rows={3} disabled={disabled} placeholder="Your answer" value={value || ''} onChange={(e) => onChange(e.target.value)} />;
  return <input className="input" disabled={disabled} placeholder="Your answer" value={value || ''} onChange={(e) => onChange(e.target.value)} />;
}
