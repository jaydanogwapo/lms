import { api, LEVELS, cap, fmtDay } from '../../api';
import { Empty, ErrorNote, LevelBadge, PageLoader, download, useLoad } from '../../ui';
import { PageHeader } from '../../components/Shell';

const blurb = {
  beginner: 'Basic concepts and introductions',
  intermediate: 'Deeper understanding and application',
  advanced: 'Complex concepts and problem solving',
};

export default function Lessons() {
  const { data, loading, error } = useLoad(() => api.get('/materials/mine/list'));
  return (
    <>
      <PageHeader title="My lessons" sub="Lessons your teacher published for your section" />
      {loading ? <PageLoader /> : error ? <ErrorNote error={error} /> : data.length === 0 ? <Empty title="No lessons yet">You'll get a Gmail notification when your teacher publishes one.</Empty> : (
        <div className="space-y-8">
          {LEVELS.map((lv) => {
            const items = data.filter((m) => m.level === lv);
            if (!items.length) return null;
            return (
              <section key={lv}>
                <div className="mb-3 flex items-center gap-3"><h2 className="text-lg font-bold">{cap(lv)}</h2><span className="text-sm text-slate-500">{blurb[lv]}</span></div>
                <div className="grid gap-4 md:grid-cols-2">
                  {items.map((m) => (
                    <div key={m.id} className="card flex flex-col">
                      <div className="mb-2 flex items-center gap-2"><LevelBadge level={m.level} />{m.course_title && <span className="text-xs text-slate-500">{m.course_title}</span>}</div>
                      <h3 className="font-bold">{m.title}</h3>
                      <p className="mt-1 flex-1 text-sm text-slate-600">{m.description || 'No description provided.'}</p>
                      <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
                        <span>Published {fmtDay(m.published_at)}</span>
                        <button className="btn-primary btn-sm" onClick={() => download(`/materials/${m.id}/download`)}>⬇ Download</button>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </>
  );
}
